import type { NatsConnection } from "@nats-io/nats-core";
import type { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { registerAgent } from "@synadia/nats-agent-shared";
import type { RegisteredAgent } from "@synadia/nats-agent-shared";
import { addPending, generateRequestId } from "./pending.js";

export async function startNatsBridge(params: {
  agentName: string;
  description: string;
  nc: NatsConnection;
  server: McpServer;
  metadata?: Record<string, string>;
}): Promise<RegisteredAgent> {
  const { agentName, description, nc, server, metadata } = params;

  return registerAgent(
    nc,
    {
      name: agentName,
      description,
      platform: "claude-code",
      metadata,
    },
    async (envelope) => {
      const requestId = generateRequestId();

      return new Promise<string>((resolve) => {
        addPending(requestId, resolve);

        // Push notification into Claude Code session
        server.server.notification({
          method: "notifications/claude/channel",
          params: {
            content: `[request_id: ${requestId}]\nFrom: ${envelope.from}\n\n${envelope.body}`,
            meta: { source: "nats", sender: envelope.from, request_id: requestId },
          },
        });
      });
    },
  );
}
