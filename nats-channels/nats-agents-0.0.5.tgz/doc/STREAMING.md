# Streaming Responses

## Overview

When streaming is enabled, the NATS agent publishes response chunks progressively instead of waiting for the complete response. Callers see text arriving in blocks as the LLM generates tokens.

The streaming mechanism uses OpenClaw's block streaming coalescer — the same infrastructure Telegram uses. Tokens are accumulated and flushed as blocks (configurable size/timing), with each block published as a separate NATS message to the caller's reply subject.

## Configuration

Set `"streaming": true` in your NATS account config in `~/.openclaw/openclaw.json`:

```json
{
  "channels": {
    "nats": {
      "accounts": {
        "default": {
          "agentName": "my-agent",
          "url": "nats://localhost:4222",
          "streaming": true
        }
      }
    }
  }
}
```

No global OpenClaw settings needed — the NATS plugin enables block streaming per-channel by intercepting the dispatch runtime. This does not affect other channels (Telegram, Discord, etc.).

The `install/openclaw.sh` installer sets this when you answer "Y" to streaming.

## How It Works

### Protocol

The caller signals streaming support via a NATS header:

```
Nats-Agent-Stream: accepted
```

The agent responds with multiple messages on the caller's reply subject, each carrying:

| Header | Values | Description |
|--------|--------|-------------|
| `Nats-Agent-Stream-Status` | `chunk`, `done` | Chunk or final message |
| `Nats-Agent-Stream-Seq` | `1`, `2`, ... | Monotonically increasing sequence |
| `Nats-Agent-Stream-Kind` | `tool`, `block`, `final` | What triggered this chunk |

The `done` message contains the complete response text (for verification or non-streaming consumers).

### INSPECT

A streaming agent advertises support in the INSPECT response:

```json
{
  "capabilities": [
    {
      "name": "prompt",
      "endpoint": "agents.my-agent.inbox",
      "pattern": "request/reply",
      "streaming": true
    }
  ]
}
```

### Caller side

Callers use `nc.requestMany()` with the `"stall"` strategy to collect chunks:

```typescript
import { sendToAgentStreaming } from "./shared/discovery.js";

const response = await sendToAgentStreaming(nc, "caller", "target", "hello", {
  onChunk: (text, { seq, done }) => {
    process.stdout.write(text);
  },
});
```

If the target doesn't advertise streaming, `sendToAgentStreaming` falls back to single-shot `sendToAgent`.

### Backward compatibility

- **No stream header** → single-shot response (same as before)
- **Streaming caller → non-streaming agent** → one message, stall timer expires, works fine
- **`nats req`** → no stream header, gets single response as before

## Coalescing Tuning

The plugin provides default coalescing settings:

```
minChars: 100    — minimum characters before flushing a block
idleMs: 500      — flush after 500ms of no new tokens
```

These can be adjusted in the plugin source (`src/channel.ts`). Smaller values = more frequent, smaller chunks. Larger values = fewer, bigger chunks.

## Testing

### Verify streaming is enabled

```bash
nats req agents.my-agent.inspect ''
# Look for "streaming": true on the prompt capability
```

### Non-streaming test (nats req)

```bash
nats req agents.my-agent.inbox '{"from":"cli","body":"hello"}' --timeout 60s
# Gets single complete response (no stream header sent)
```

### Streaming test (stream-req.sh)

```bash
bash test/stream-req.sh my-agent "write a 10-line poem"
# Subscribes to reply inbox, sends request with stream header
# Chunks appear progressively as the LLM generates
# Ctrl-C to stop
```

### Integration tests

```bash
npm test
# Includes streaming tests: plaintext, encrypted, and fallback
```

## Encrypted Streaming

When both `encryption: true` and `streaming: true` are enabled, chunks are encrypted using a session key derived from the initial request. Each chunk uses a unique IV (base IV XOR sequence number). The header `Nats-Agent-Crypto-Mode: stream` signals session-key decryption.

## Limitations

- **Block-level granularity**: Chunks are coalesced blocks (~100+ chars), not individual tokens. A line may be split across chunks.
- **Tool results**: Not currently sent as streaming chunks from the OpenClaw gateway (only LLM text blocks are coalesced).
