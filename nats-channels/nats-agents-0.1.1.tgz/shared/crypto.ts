/**
 * Hybrid encryption for agent-to-agent messages.
 * Adopted from github.com/synadia-io/agent-js/src/crypto.ts
 *
 * Scheme:
 * - Fresh random AES-256-GCM key encrypts the payload
 * - The AES key is sealed (NaCl box) with sender's XKey + recipient's public XKey
 * - Sender's public XKey goes in a header so recipient can unseal
 */

import { createCipheriv, createDecipheriv, randomBytes } from "crypto";
import type { KeyPair } from "@nats-io/nkeys";

export const HEADER_SYM_KEY = "Synadia-Sym-Key";
export const HEADER_SENDER_XKEY = "Synadia-Sender-Xkey";

const SYM_KEY_BYTES = 32;
const IV_BYTES = 12;
const AUTH_TAG_BYTES = 16;

export interface EncryptedMessage {
  payload: Uint8Array;
  headers: Record<string, string>;
}

export function encryptMessage(
  payload: Uint8Array,
  senderXKey: KeyPair,
  recipientPublicXKey: string,
): EncryptedMessage {
  const symKey = randomBytes(SYM_KEY_BYTES);
  const iv = randomBytes(IV_BYTES);

  const cipher = createCipheriv("aes-256-gcm", symKey, iv);
  const ciphertext = Buffer.concat([cipher.update(payload), cipher.final()]);
  const authTag = cipher.getAuthTag();

  const encryptedPayload = new Uint8Array(IV_BYTES + ciphertext.length + AUTH_TAG_BYTES);
  encryptedPayload.set(iv, 0);
  encryptedPayload.set(ciphertext, IV_BYTES);
  encryptedPayload.set(authTag, IV_BYTES + ciphertext.length);

  const sealedSymKey = senderXKey.seal(new Uint8Array(symKey), recipientPublicXKey);

  return {
    payload: encryptedPayload,
    headers: {
      [HEADER_SYM_KEY]: Buffer.from(sealedSymKey).toString("base64"),
      [HEADER_SENDER_XKEY]: senderXKey.getPublicKey(),
    },
  };
}

export interface SessionKeyMaterial {
  sessionKey: Uint8Array;
  iv: Uint8Array;
}

export interface EncryptedMessageWithSession extends EncryptedMessage {
  session: SessionKeyMaterial;
}

/** Like encryptMessage but also returns the session key + IV for stream chunk encryption. */
export function encryptMessageRetainingSession(
  payload: Uint8Array,
  senderXKey: KeyPair,
  recipientPublicXKey: string,
): EncryptedMessageWithSession {
  const symKey = randomBytes(SYM_KEY_BYTES);
  const iv = randomBytes(IV_BYTES);

  const cipher = createCipheriv("aes-256-gcm", symKey, iv);
  const ciphertext = Buffer.concat([cipher.update(payload), cipher.final()]);
  const authTag = cipher.getAuthTag();

  const encryptedPayload = new Uint8Array(IV_BYTES + ciphertext.length + AUTH_TAG_BYTES);
  encryptedPayload.set(iv, 0);
  encryptedPayload.set(ciphertext, IV_BYTES);
  encryptedPayload.set(authTag, IV_BYTES + ciphertext.length);

  const sealedSymKey = senderXKey.seal(new Uint8Array(symKey), recipientPublicXKey);

  return {
    payload: encryptedPayload,
    headers: {
      [HEADER_SYM_KEY]: Buffer.from(sealedSymKey).toString("base64"),
      [HEADER_SENDER_XKEY]: senderXKey.getPublicKey(),
    },
    session: { sessionKey: new Uint8Array(symKey), iv },
  };
}

/** Like decryptMessage but also returns the session key + IV for stream chunk decryption. */
export function decryptMessageRetainingSession(
  payload: Uint8Array,
  headers: Record<string, string>,
  recipientXKey: KeyPair,
): { plaintext: Uint8Array; session: SessionKeyMaterial } {
  const senderPublicXKey = headers[HEADER_SENDER_XKEY];
  if (!senderPublicXKey) throw new Error(`missing header: ${HEADER_SENDER_XKEY}`);
  const rawSealedKey = headers[HEADER_SYM_KEY];
  if (!rawSealedKey) throw new Error(`missing header: ${HEADER_SYM_KEY}`);

  const sealedSymKey = new Uint8Array(Buffer.from(rawSealedKey, "base64"));
  const symKey = recipientXKey.open(sealedSymKey, senderPublicXKey);
  if (!symKey) throw new Error("failed to decrypt symmetric key");

  const iv = payload.slice(0, IV_BYTES);
  const authTag = payload.slice(payload.length - AUTH_TAG_BYTES);
  const ciphertext = payload.slice(IV_BYTES, payload.length - AUTH_TAG_BYTES);

  const decipher = createDecipheriv("aes-256-gcm", symKey, iv);
  decipher.setAuthTag(authTag);
  const plaintext = new Uint8Array(Buffer.concat([decipher.update(ciphertext), decipher.final()]));

  return { plaintext, session: { sessionKey: new Uint8Array(symKey), iv } };
}

/** Derive a per-chunk IV from the base IV and sequence number. */
function deriveChunkIv(baseIv: Uint8Array, seq: number): Uint8Array {
  const iv = new Uint8Array(baseIv);
  // XOR the last 4 bytes with the sequence number
  const view = new DataView(iv.buffer, iv.byteOffset, iv.byteLength);
  view.setUint32(IV_BYTES - 4, view.getUint32(IV_BYTES - 4) ^ seq);
  return iv;
}

/** Encrypt a stream chunk using a session key with sequence-derived IV. */
export function encryptChunk(
  session: SessionKeyMaterial,
  seq: number,
  plaintext: Uint8Array,
): Uint8Array {
  const iv = deriveChunkIv(session.iv, seq);
  const cipher = createCipheriv("aes-256-gcm", session.sessionKey, iv);
  const ciphertext = Buffer.concat([cipher.update(plaintext), cipher.final()]);
  const authTag = cipher.getAuthTag();

  const out = new Uint8Array(IV_BYTES + ciphertext.length + AUTH_TAG_BYTES);
  out.set(iv, 0);
  out.set(ciphertext, IV_BYTES);
  out.set(authTag, IV_BYTES + ciphertext.length);
  return out;
}

/** Decrypt a stream chunk using a session key. */
export function decryptChunk(
  session: SessionKeyMaterial,
  seq: number,
  payload: Uint8Array,
): Uint8Array {
  const iv = payload.slice(0, IV_BYTES);
  const authTag = payload.slice(payload.length - AUTH_TAG_BYTES);
  const ciphertext = payload.slice(IV_BYTES, payload.length - AUTH_TAG_BYTES);

  const decipher = createDecipheriv("aes-256-gcm", session.sessionKey, iv);
  decipher.setAuthTag(authTag);
  return new Uint8Array(Buffer.concat([decipher.update(ciphertext), decipher.final()]));
}

export function decryptMessage(
  payload: Uint8Array,
  headers: Record<string, string>,
  recipientXKey: KeyPair,
): Uint8Array {
  const senderPublicXKey = headers[HEADER_SENDER_XKEY];
  if (!senderPublicXKey) {
    throw new Error(`missing header: ${HEADER_SENDER_XKEY}`);
  }

  const rawSealedKey = headers[HEADER_SYM_KEY];
  if (!rawSealedKey) {
    throw new Error(`missing header: ${HEADER_SYM_KEY}`);
  }

  const sealedSymKey = new Uint8Array(Buffer.from(rawSealedKey, "base64"));
  const symKey = recipientXKey.open(sealedSymKey, senderPublicXKey);
  if (!symKey) {
    throw new Error("failed to decrypt symmetric key: invalid sealed key or wrong recipient");
  }

  const iv = payload.slice(0, IV_BYTES);
  const authTag = payload.slice(payload.length - AUTH_TAG_BYTES);
  const ciphertext = payload.slice(IV_BYTES, payload.length - AUTH_TAG_BYTES);

  const decipher = createDecipheriv("aes-256-gcm", symKey, iv);
  decipher.setAuthTag(authTag);

  return new Uint8Array(Buffer.concat([decipher.update(ciphertext), decipher.final()]));
}
