import { Type } from "@sinclair/typebox";
import type { NatsConnection } from "@nats-io/nats-core";
import type { AgentIdentity } from "../shared/index.js";
import type { ChannelAgentTool } from "openclaw/plugin-sdk";
import {
  discoverAgents,
  getAgentInfo,
  sendToAgent,
} from "../shared/index.js";

export function createNatsAgentTools(
  getNc: () => NatsConnection | null,
  getAgentName: () => string | null,
  getIdentity: () => AgentIdentity | null,
  getEncryption: () => boolean,
  getOrg: () => string | undefined,
): ChannelAgentTool[] {
  function requireNc(): NatsConnection {
    const nc = getNc();
    if (!nc) throw new Error("NATS not connected");
    return nc;
  }

  const ownName = () => getAgentName() ?? "openclaw";

  return [
    {
      name: "discover_agents",
      label: "Discover Agents",
      description:
        "Find all NATS-connected agents on the network. Returns name, description, platform for each. Your own entry is marked with (you).",
      parameters: Type.Object({}),
      execute: async () => {
        const agents = await discoverAgents(requireNc());
        const self = ownName();
        const annotated = agents.map((a) => ({
          ...a,
          ...(a.name === self ? { self: true } : {}),
        }));
        const header = `Your NATS identity: ${self}\n\n`;
        return {
          content: [{ type: "text" as const, text: header + JSON.stringify(annotated, null, 2) }],
        };
      },
    },
    {
      name: "agent_info",
      label: "Agent Info",
      description: "Get detailed capabilities of a specific agent by name.",
      parameters: Type.Object({
        name: Type.String({ description: "The agent name to inspect" }),
      }),
      execute: async (_toolCallId: string, args: unknown) => {
        const { name } = args as { name: string };
        const info = await getAgentInfo(requireNc(), name, { org: getOrg() });
        return {
          content: [{ type: "text" as const, text: JSON.stringify(info, null, 2) }],
        };
      },
    },
    {
      name: "send_to_agent",
      label: "Send to Agent",
      description:
        "Send a message to another agent and get the response. Uses NATS request/reply. Messages are sent as your NATS identity.",
      parameters: Type.Object({
        name: Type.String({ description: "Target agent name" }),
        message: Type.String({ description: "Message to send" }),
      }),
      execute: async (_toolCallId: string, args: unknown) => {
        const { name, message } = args as { name: string; message: string };
        try {
          console.log(`[nats-tool] send_to_agent: sending to "${name}"...`);
          const nc = requireNc();
          console.log(`[nats-tool] nc connected: ${!nc.isClosed()}, draining: ${nc.isDraining()}`);
          const identity = getIdentity();
          const response = await sendToAgent(nc, ownName(), name, message, {
            identity: identity ?? undefined,
            encryption: getEncryption(),
            org: getOrg(),
            stallMs: 5000,
          });
          console.log(`[nats-tool] send_to_agent: got response (${response.length} chars)`);
          return {
            content: [{ type: "text" as const, text: response }],
          };
        } catch (err) {
          console.log(`[nats-tool] send_to_agent ERROR: ${(err as Error).message}`);
          return {
            content: [{ type: "text" as const, text: `Error: ${(err as Error).message}` }],
          };
        }
      },
    },
  ];
}
