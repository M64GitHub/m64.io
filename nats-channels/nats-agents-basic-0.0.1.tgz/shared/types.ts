import type { NatsConnection, Subscription } from "@nats-io/nats-core";
import type { Service } from "@nats-io/services";

// --- Connection ---

export interface ConnectionConfig {
  url?: string;
  credentials?: string;
  name?: string;
}

// --- Agent Registration ---

export interface AgentConfig {
  name: string;
  description: string;
  version?: string;
  platform: string;
  org?: string;
  metadata?: Record<string, string>;
}

// --- Agent Info ---

export interface AgentInfo {
  name: string;
  id: string;
  version: string;
  description: string;
  platform: string;
  metadata: Record<string, string>;
}

// --- INSPECT Response ---

export interface Capability {
  name: string;
  endpoint: string;
  description: string;
  pattern: "request/reply" | "pub/sub";
  streaming?: boolean;
}

export interface InspectResponse {
  name: string;
  description: string;
  capabilities: Capability[];
}

// --- Wire Format ---

export interface MessageEnvelope {
  from: string;
  body: string;
}

// --- Handler ---

export type MessageHandler = (envelope: MessageEnvelope) => Promise<string>;

// --- Streaming ---

export interface StreamResponder {
  /** Publish an incremental chunk to the caller. */
  sendChunk(text: string): void;
  /** Whether the caller requested streaming. */
  readonly isStreaming: boolean;
}

export type StreamingMessageHandler = (
  envelope: MessageEnvelope,
  stream: StreamResponder,
) => Promise<string>;

// --- Registration Result ---

export interface RegisteredAgent {
  service: Service;
  stop: () => Promise<void>;
}
