export interface NatsAccountConfig {
  url?: string;
  agentName: string;
  description?: string;
  credentials?: string;
  enabled?: boolean;
  encryption?: boolean;
  streaming?: boolean;
  org?: string;
}

export interface ResolvedNatsAccount {
  accountId: string;
  enabled: boolean;
  url: string;
  agentName: string;
  description: string;
  credentials?: string;
  encryption: boolean;
  streaming: boolean;
  org?: string;
  config: NatsAccountConfig;
}
