import type { NatsConnection, Subscription } from "@nats-io/nats-core";
import { Svcm } from "@nats-io/services";
import type { Service, ServiceHandler } from "@nats-io/services";
import type { ChannelGatewayContext } from "openclaw/plugin-sdk";
import { dispatchInboundDirectDmWithRuntime } from "openclaw/plugin-sdk/direct-dm";
import {
  connectToNats,
  drainConnection,
  parseEnvelope,
  agentSubject,
  inspectSubject,
  buildInspectResponse,
  generateIdentity,
  AGENT_TYPE,
  DEFAULT_VERSION,
} from "../shared/index.js";
import type { ResolvedNatsAccount } from "./types.js";
import { setActiveConnection } from "./runtime.js";

// Track active gateway for cleanup on re-entry
let activeService: Service | null = null;
let activeInspectSub: Subscription | null = null;
let activeNc: NatsConnection | null = null;

async function cleanupPrevious(): Promise<void> {
  if (activeInspectSub) {
    activeInspectSub.unsubscribe();
    activeInspectSub = null;
  }
  if (activeService) {
    await activeService.stop();
    activeService = null;
  }
  if (activeNc) {
    await drainConnection(activeNc);
    activeNc = null;
  }
  setActiveConnection(null, null);
}

export async function startNatsGateway(
  ctx: ChannelGatewayContext<ResolvedNatsAccount>,
): Promise<void> {
  // Clean up previous registration if startAccount is called again
  await cleanupPrevious();

  const { account, cfg, abortSignal, channelRuntime } = ctx;
  const agentName = account.agentName;

  // 1. Connect to NATS
  const nc = await connectToNats({
    url: account.url,
    credentials: account.credentials,
    name: `openclaw-${agentName}`,
  });

  // 2. Register micro service
  const identity = generateIdentity();

  // Store connection + identity for tools/outbound
  setActiveConnection(nc, agentName, identity, account.encryption, account.org);
  ctx.setStatus({ state: "running" });

  const svc = new Svcm(nc);
  const service = await svc.add({
    name: agentName,
    version: DEFAULT_VERSION,
    description: account.description,
    metadata: {
      type: AGENT_TYPE,
      platform: "openclaw",
      description: account.description,
      public_nkey: identity.publicNKey,
      public_xkey: identity.publicXKey,
    },
  });

  // 3. Inbox endpoint — always streams response chunks to msg.reply
  const inboxHandler: ServiceHandler = (err, msg) => {
    if (err || !msg.reply) return;

    let envelope;
    try {
      envelope = parseEnvelope(msg.data);
    } catch (e) {
      msg.respondError(400, (e as Error).message);
      return;
    }

    // Always enable block streaming in OpenClaw
    const effectiveRuntime = {
      ...channelRuntime,
      reply: {
        ...channelRuntime.reply,
        dispatchReplyWithBufferedBlockDispatcher: (params: Record<string, unknown>) => {
          return channelRuntime.reply.dispatchReplyWithBufferedBlockDispatcher({
            ...params,
            replyOptions: {
              ...(params.replyOptions as Record<string, unknown> | undefined),
              disableBlockStreaming: false,
            },
          });
        },
      },
    };

    dispatchInboundDirectDmWithRuntime({
      cfg,
      runtime: { channel: effectiveRuntime },
      channel: "nats",
      channelLabel: "NATS",
      accountId: account.accountId,
      peer: { kind: "direct", id: envelope.from },
      senderId: envelope.from,
      senderAddress: `nats:${envelope.from}`,
      recipientAddress: `nats:${agentName}`,
      conversationLabel: envelope.from,
      rawBody: envelope.body,
      messageId: `nats-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
      timestamp: Date.now(),
      commandAuthorized: true,
      deliver: async (payload, info) => {
        const text = payload.text ?? "";
        if (!text) return;
        // Publish every chunk to reply subject
        nc.publish(msg.reply!, text);
        // After final delivery, send empty done signal
        if (!info || info.kind === "final") {
          nc.publish(msg.reply!, "");
        }
      },
      onRecordError: (err) => {
        ctx.log?.error?.(`nats: session record error: ${String(err)}`);
      },
      onDispatchError: (err, info) => {
        ctx.log?.error?.(`nats: ${info.kind} dispatch error: ${String(err)}`);
        try {
          msg.respond(JSON.stringify({ error: String(err) }));
        } catch {}
      },
    }).catch((err) => {
      ctx.log?.error?.(`nats: dispatch failed: ${String(err)}`);
      try {
        msg.respondError(500, String(err));
      } catch {}
    });
  };

  service.addEndpoint("inbox", {
    subject: agentSubject(agentName, account.org),
    handler: inboxHandler,
  });

  // 4. INSPECT endpoint (single-shot — not an LLM call)
  const inspectResponse = JSON.stringify(
    buildInspectResponse(
      { name: agentName, description: account.description, platform: "openclaw", encryption: account.encryption, org: account.org },
      identity,
    ),
  );

  const inspectSub = nc.subscribe(inspectSubject(agentName, account.org), {
    callback: (_err, msg) => {
      msg.respond(inspectResponse);
    },
  });

  // Track for cleanup
  activeService = service;
  activeInspectSub = inspectSub;
  activeNc = nc;

  ctx.log?.info?.(`nats: agent "${agentName}" registered — subject: ${agentSubject(agentName, account.org)}`);

  // 5. Stay alive until abort — OpenClaw expects startAccount to remain pending
  return new Promise<void>((resolve) => {
    abortSignal.addEventListener("abort", () => {
      cleanupPrevious().then(
        () => ctx.log?.info?.(`nats: agent "${agentName}" stopped`),
        (err) => ctx.log?.error?.(`nats: shutdown error: ${String(err)}`),
      ).finally(resolve);
    });
  });
}

export async function stopNatsGateway(
  ctx: ChannelGatewayContext<ResolvedNatsAccount>,
): Promise<void> {
  await cleanupPrevious();
}
