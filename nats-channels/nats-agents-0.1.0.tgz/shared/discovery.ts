import type { NatsConnection } from "@nats-io/nats-core";
import { Svcm } from "@nats-io/services";
import { randomUUID } from "crypto";
import type { AgentInfo, InspectResponse } from "./types.js";
import type { AgentIdentity } from "./identity.js";
import { encryptMessage, decryptMessage } from "./crypto.js";
import {
  AGENT_TYPE,
  buildEnvelope,
  inboxSubject,
  inspectSubject,
  toNatsHeaders,
  fromNatsHeaders,
} from "./protocol.js";

const DEFAULT_DISCOVERY_TIMEOUT = 3000;
const DEFAULT_AGENT_TIMEOUT = 120_000;

export async function discoverAgents(
  nc: NatsConnection,
  timeout: number = DEFAULT_DISCOVERY_TIMEOUT,
): Promise<AgentInfo[]> {
  const svc = new Svcm(nc);
  const client = svc.client({ strategy: "stall", maxWait: timeout });
  const pings = await client.ping();

  const agents: AgentInfo[] = [];
  for await (const identity of pings) {
    if (identity.metadata?.type !== AGENT_TYPE) continue;
    agents.push({
      name: identity.name,
      id: identity.id,
      version: identity.version,
      description: identity.metadata.description ?? "",
      platform: identity.metadata.platform ?? "unknown",
      metadata: identity.metadata,
    });
  }

  return agents;
}

export async function getAgentInfo(
  nc: NatsConnection,
  name: string,
  opts?: {
    timeout?: number;
    identity?: AgentIdentity;
  },
): Promise<InspectResponse> {
  const timeout = opts?.timeout ?? DEFAULT_DISCOVERY_TIMEOUT;
  const nonce = randomUUID();
  const msg = await nc.request(inspectSubject(name), nonce, { timeout });
  const info = JSON.parse(msg.string()) as InspectResponse;

  // Verify the agent signed our nonce (proves key ownership)
  if (opts?.identity) {
    info.verified = opts.identity.verify(nonce, info.identity.signature, info.identity.publicNKey);
  }

  return info;
}

/**
 * Send a message to another agent and get the response.
 * When identity is provided, the message is end-to-end encrypted:
 * 1. INSPECT the target to get their public XKey (extra round-trip)
 * 2. Encrypt the envelope with AES-256-GCM + sealed symmetric key
 * 3. Decrypt the response
 * TODO: Cache known XKeys to avoid the INSPECT round-trip on every send.
 */
export async function sendToAgent(
  nc: NatsConnection,
  senderName: string,
  targetName: string,
  message: string,
  opts?: {
    timeout?: number;
    identity?: AgentIdentity;
    encryption?: boolean;
  },
): Promise<string> {
  const timeout = opts?.timeout ?? DEFAULT_AGENT_TIMEOUT;
  const identity = opts?.identity;
  const encryption = opts?.encryption === true;
  const envelopeStr = buildEnvelope(senderName, message);

  if (identity && encryption) {
    // Encrypted path: get target's XKey + verify identity, encrypt, send, decrypt response
    const info = await getAgentInfo(nc, targetName, { identity });
    const targetXKey = info.identity.publicXKey;

    const encrypted = encryptMessage(
      new TextEncoder().encode(envelopeStr),
      identity.xkey,
      targetXKey,
    );

    const msg = await nc.request(inboxSubject(targetName), encrypted.payload, {
      timeout,
      headers: toNatsHeaders(encrypted.headers),
    });

    const responseHdrs = fromNatsHeaders(msg.headers);
    const decrypted = decryptMessage(msg.data, responseHdrs, identity.xkey);
    return new TextDecoder().decode(decrypted);
  }

  // Plaintext path (backward compat)
  const msg = await nc.request(inboxSubject(targetName), envelopeStr, { timeout });
  return msg.string();
}
