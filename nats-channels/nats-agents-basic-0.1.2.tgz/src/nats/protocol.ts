import { headers as createHeaders } from "@nats-io/nats-core";
import type { MsgHdrs } from "@nats-io/nats-core";
import type { AgentConfig, Capability, InspectResponse, MessageEnvelope } from "./types.js";

// --- Constants ---

export const AGENT_TYPE = "agent";
export const DEFAULT_VERSION = "0.1.2";

// --- Subject Builders ---

export function agentSubject(name: string, org?: string): string {
  return org ? `agents.oc.${org}.${name}` : `agents.oc.${name}`;
}

export function inspectSubject(name: string, org?: string): string {
  return `${agentSubject(name, org)}.inspect`;
}

export function outboundSubject(name: string, org?: string): string {
  return `${agentSubject(name, org)}.outbound`;
}

/** @deprecated Use agentSubject() — kept for backward compat */
export const inboxSubject = agentSubject;

// --- INSPECT Response Builder ---

export function buildInspectResponse(config: AgentConfig): InspectResponse {
  const capabilities: Capability[] = [
    {
      name: "prompt",
      endpoint: agentSubject(config.name, config.org),
      description: "Send a prompt and receive a streamed response. Use natural language.",
      pattern: "request/reply",
    },
    {
      name: "notifications",
      endpoint: outboundSubject(config.name, config.org),
      description: "Subscribe to receive agent-initiated messages.",
      pattern: "pub/sub",
    },
  ];

  return {
    name: config.name,
    description: config.description,
    capabilities,
  };
}

// --- Envelope Utilities ---

export function buildEnvelope(from: string, body: string): string {
  return JSON.stringify({ from, body });
}

export function parseEnvelope(data: Uint8Array | string): MessageEnvelope {
  const text = typeof data === "string" ? data : new TextDecoder().decode(data);
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    // Plain text fallback — treat entire payload as body
    return { from: "anonymous", body: text };
  }

  if (
    typeof parsed === "object" &&
    parsed !== null &&
    typeof (parsed as Record<string, unknown>).body === "string"
  ) {
    return {
      from: typeof (parsed as Record<string, unknown>).from === "string"
        ? (parsed as Record<string, unknown>).from as string
        : "anonymous",
      body: (parsed as Record<string, unknown>).body as string,
    };
  }

  // JSON but not an envelope — treat as plain text
  return { from: "anonymous", body: text };
}

// --- NATS Header Helpers ---

export function toNatsHeaders(entries: Record<string, string>): MsgHdrs {
  const hdrs = createHeaders();
  for (const [key, value] of Object.entries(entries)) {
    hdrs.set(key, value);
  }
  return hdrs;
}

export function fromNatsHeaders(hdrs: MsgHdrs | undefined): Record<string, string> {
  const result: Record<string, string> = {};
  if (!hdrs) return result;
  for (const key of hdrs.keys()) {
    const values = hdrs.values(key);
    if (values && values.length > 0) {
      result[key] = values[0];
    }
  }
  return result;
}
