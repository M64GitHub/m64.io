import type { NatsConnection } from "@nats-io/nats-core";
import type { AgentIdentity } from "../shared/index.js";
import type { PluginRuntime } from "openclaw/plugin-sdk/core";
import { createPluginRuntimeStore } from "openclaw/plugin-sdk/compat";

export type NatsRuntime = PluginRuntime;

export const {
  setRuntime: setNatsRuntime,
  clearRuntime: clearNatsRuntime,
  getRuntime: getNatsRuntime,
} = createPluginRuntimeStore<NatsRuntime>("NATS runtime not initialized");

// Active connection state — set by gateway, read by tools and outbound
let activeNc: NatsConnection | null = null;
let activeAgentName: string | null = null;
let activeIdentity: AgentIdentity | null = null;
let activeEncryption: boolean = false;
let activeStreaming: boolean = false;

export function setActiveConnection(
  nc: NatsConnection | null,
  agentName: string | null,
  identity?: AgentIdentity | null,
  encryption?: boolean,
  streaming?: boolean,
): void {
  activeNc = nc;
  activeAgentName = agentName;
  activeIdentity = identity ?? null;
  activeEncryption = encryption ?? false;
  activeStreaming = streaming ?? false;
}

export function getActiveConnection(): NatsConnection | null {
  return activeNc;
}

export function getActiveAgentName(): string | null {
  return activeAgentName;
}

export function getActiveIdentity(): AgentIdentity | null {
  return activeIdentity;
}

export function getActiveEncryption(): boolean {
  return activeEncryption;
}

export function getActiveStreaming(): boolean {
  return activeStreaming;
}
