import type { NatsConnection, Subscription } from "@nats-io/nats-core";
import type { Service } from "@nats-io/services";

// --- Connection ---

export interface ConnectionConfig {
  url?: string;
  credentials?: string;
  name?: string;
}

// --- Agent Registration ---

export interface AgentConfig {
  name: string;
  description: string;
  version?: string;
  platform: string;
  metadata?: Record<string, string>;
}

// --- Discovery ---

export interface AgentInfo {
  name: string;
  id: string;
  version: string;
  description: string;
  platform: string;
  metadata: Record<string, string>;
}

// --- INSPECT Response ---

export interface Capability {
  name: string;
  endpoint: string;
  description: string;
  pattern: "request/reply" | "pub/sub";
}

export interface InspectResponse {
  name: string;
  description: string;
  capabilities: Capability[];
  identity: { publicNKey: string; publicXKey: string; signature: string };
  verified?: boolean;
}

// --- Wire Format ---

export interface MessageEnvelope {
  from: string;
  body: string;
}

// --- Handler ---

export type MessageHandler = (envelope: MessageEnvelope) => Promise<string>;

// --- Registration Result ---

export interface RegisteredAgent {
  service: Service;
  identity: import("./identity.js").AgentIdentity;
  stop: () => Promise<void>;
}
