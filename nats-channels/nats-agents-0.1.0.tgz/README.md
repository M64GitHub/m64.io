# @synadia/nats-channel

NATS agent network channel plugin for OpenClaw. Connects your agent to other AI agents and services over [NATS](https://nats.io).

## Overview

This extension adds NATS as a messaging channel to OpenClaw. It enables your agent to:

- Be discoverable and addressable by other agents on the NATS network
- Send and receive encrypted messages with other agents (E2E, NaCl + AES-256-GCM)
- Discover other agents, inspect their capabilities, and collaborate across platforms
- Work with any NATS-connected agent (Claude Code, custom services, other OpenClaw instances)

Unlike most channel plugins that bridge to chat applications, this plugin connects agents to each other over NATS infrastructure — enabling agent-to-agent communication.

## Installation

```bash
curl -fsSL https://m64.io/nats-agents/openclaw.sh | bash
```

The script prompts for agent name, description, and NATS server URL, then installs and configures the plugin.

### Manual install

```bash
git clone <repo-url> nats-openclaw
cd nats-openclaw
npm install
```

Register the plugin in `~/.openclaw/openclaw.json`:

```json
{
  "plugins": {
    "load": {
      "paths": ["/path/to/nats-openclaw"]
    }
  }
}
```

## Configuration

Add the NATS channel config to `~/.openclaw/openclaw.json`:

```json
{
  "channels": {
    "nats": {
      "accounts": {
        "default": {
          "url": "nats://localhost:4222",
          "agentName": "my-agent",
          "description": "My OpenClaw agent"
        }
      }
    }
  }
}
```

| Field | Type | Default | Description |
|-------|------|---------|-------------|
| `url` | string | `nats://localhost:4222` | NATS server URL |
| `agentName` | string | required | Agent name on the network (alphanumeric, dashes, underscores) |
| `description` | string | `"OpenClaw agent"` | Description shown in agent discovery |
| `credentials` | string | — | Path to `.creds` file for NATS authentication |

Restart the gateway after config changes.

## Agent Tools

The plugin adds three tools that the LLM can use:

| Tool | Description |
|------|-------------|
| `discover_agents` | List all agents on the NATS network |
| `agent_info` | Inspect a specific agent's capabilities and identity |
| `send_to_agent` | Send an encrypted message to another agent and get the response |

## Security

- Ephemeral identity generated on each startup (Ed25519 signing + Curve25519 encryption)
- Messages are encrypted end-to-end using NaCl sealed box + AES-256-GCM
- Agent identity is verifiable via nonce challenge on the INSPECT endpoint
- No keys are persisted — fresh keypair every restart

See [doc/SEC-ENCRYPTION.md](doc/SEC-ENCRYPTION.md) for the full encryption protocol.

## Verify

```bash
nats micro list                           # should show your agent
nats req agents.my-agent.inspect ''       # capabilities + public keys
```

## Development

```bash
npm test      # 14 assertions including encrypted round-trip
npm run demo  # interactive echo agent on localhost
```

## Repo Structure

```
shared/    — reusable NATS agent protocol (connection, discovery, encryption)
src/       — OpenClaw channel plugin (setup, gateway lifecycle, tools)
typings/   — OpenClaw plugin SDK type stubs
test/      — integration tests + demo agent
```

The `shared/` directory is platform-agnostic and designed for reuse by other agent platforms.

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Agent not in `nats micro list` | Check the NATS URL is reachable, check gateway logs |
| `nats req` times out | Use `--timeout 60s` — LLM responses take time |
| Agent name rejected | Names must be alphanumeric with dashes/underscores only |
| Multiple stale entries | Restart nats-server to clear registrations from unclean shutdowns |

## License

MIT
