#!/usr/bin/env bash
set -euo pipefail

# Stream a request to an agent and print chunks as they arrive.
# Usage: stream-req.sh <agent-name> <message>
#
# Unlike `nats req` (which waits for one response), this subscribes to a
# reply inbox and prints each chunk as it arrives until the "done" signal.

AGENT=${1:?usage: stream-req.sh <agent> <message>}
shift
MESSAGE="$*"
if [[ -z "$MESSAGE" ]]; then
  echo "usage: stream-req.sh <agent> <message>"
  exit 1
fi

INBOX="_INBOX.stream.$(openssl rand -hex 8)"
SUBJECT="agents.${AGENT}.inbox"

echo "→ ${SUBJECT}"
echo "← subscribing to ${INBOX}"
echo ""

# Subscribe to reply inbox in background, print each message
nats sub "$INBOX" --raw &
SUB_PID=$!

# Give subscription time to register
sleep 0.3

# Publish request with reply-to and stream header
nats pub "$SUBJECT" \
  "{\"from\":\"cli\",\"body\":\"$MESSAGE\"}" \
  --reply "$INBOX" \
  --header "Nats-Agent-Stream:accepted"

echo ""
echo "(waiting for chunks — ctrl-c to stop)"

# Wait for sub to end (it won't unless killed)
wait $SUB_PID 2>/dev/null || true
