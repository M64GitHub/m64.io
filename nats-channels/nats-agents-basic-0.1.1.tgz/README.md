# @m64/nats-channel

NATS messaging channel plugin for [OpenClaw](https://openclaw.ai). Registers your agent as a [NATS microservice](https://nats.io) — discoverable, addressable, and streaming responses over NATS infrastructure.

### Subject convention

Your agent listens on a NATS subject based on its name and optional org namespace:

| Config | Subject |
|--------|---------|
| `agentName: "echo"` | `agents.oc.echo` |
| `agentName: "echo"`, `org: "acme"` | `agents.oc.acme.echo` |

Use `org` on shared servers (like `demo.nats.io`) to isolate your agents from others.

## Install

```bash
openclaw plugins install @m64/nats-channel
```

Or use the one-line installer with a guided config wizard:

```bash
curl -fsSL https://m64.io/nats-channels/openclaw.sh | bash
```

## Configure

Add the NATS channel to your OpenClaw config (`~/.openclaw/openclaw.json`):

```json
{
  "channels": {
    "nats": {
      "accounts": {
        "default": {
          "url": "nats://demo.nats.io",
          "agentName": "my-agent",
          "description": "My OpenClaw agent"
        }
      }
    }
  }
}
```

Then restart the gateway:

```bash
openclaw gateway restart
```

### Config fields

| Field | Required | Default | Description |
|-------|----------|---------|-------------|
| `url` | no | `nats://localhost:4222` | NATS server URL |
| `agentName` | yes | — | Agent name on the network (letters, numbers, dashes, underscores) |
| `description` | no | `"OpenClaw agent"` | Shown when other agents discover you |
| `credentials` | no | — | Path to `.creds` file for NATS authentication |
| `org` | no | — | Organization namespace for subject isolation on shared servers |

## Verify

```bash
nats micro list                              # agent should appear
nats micro info my-agent                     # service details + endpoints
```

## Send a message

Responses stream as chunks, terminated by an empty payload. Plain text or JSON envelope:

```bash
# Plain text — sender defaults to "anonymous"
nats req agents.oc.my-agent 'Hello!' --wait-for-empty --timeout 60s

# JSON envelope — identify yourself
nats req agents.oc.my-agent '{"from":"cli","body":"Hello!"}' --wait-for-empty --timeout 60s
```

### Example with org namespace on demo.nats.io

Config:
```json
{
  "channels": {
    "nats": {
      "accounts": {
        "default": {
          "url": "nats://demo.nats.io",
          "agentName": "my-agent",
          "description": "My OpenClaw agent",
          "org": "acme"
        }
      }
    }
  }
}
```

```bash
nats req agents.oc.acme.my-agent '{"from":"cli","body":"Hello!"}' --server demo.nats.io --wait-for-empty --timeout 60s
```

## How it works

Your agent registers as a NATS microservice. Incoming messages are JSON envelopes (`{"from":"sender","body":"text"}`) dispatched through the OpenClaw pipeline. Responses stream back as chunks published to the caller's reply subject, with an empty payload signaling completion.

The agent is discoverable via standard NATS service introspection (`$SRV.PING`) and exposes an INSPECT endpoint at `agents.oc.{name}.inspect` (or `agents.oc.{org}.{name}.inspect` with org).

## License

MIT
