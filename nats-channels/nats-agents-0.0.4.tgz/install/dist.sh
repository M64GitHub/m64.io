#!/usr/bin/env bash
set -euo pipefail

VERSION=${1:?usage: dist.sh <version>  (e.g. dist.sh 0.1.0)}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname "$SCRIPT_DIR")"
cd "$REPO_DIR"

echo "=== Building nats-channel v${VERSION} ==="

# --- 1. Stamp version everywhere ---

# package.json (full)
sed -i "s/\"version\": \"[^\"]*\"/\"version\": \"${VERSION}\"/" package.json

# basic/package.json
sed -i "s/\"version\": \"[^\"]*\"/\"version\": \"${VERSION}\"/" basic/package.json

# shared/protocol.ts (full)
sed -i "s/DEFAULT_VERSION = \"[^\"]*\"/DEFAULT_VERSION = \"${VERSION}\"/" shared/protocol.ts

# basic/shared/protocol.ts
sed -i "s/DEFAULT_VERSION = \"[^\"]*\"/DEFAULT_VERSION = \"${VERSION}\"/" basic/shared/protocol.ts

# install/openclaw.sh
sed -i "s/PLUGIN_VERSION=\"[^\"]*\"/PLUGIN_VERSION=\"${VERSION}\"/" "$SCRIPT_DIR/openclaw.sh"

# install/openclaw-full.sh
sed -i "s/PLUGIN_VERSION=\"[^\"]*\"/PLUGIN_VERSION=\"${VERSION}\"/" "$SCRIPT_DIR/openclaw-full.sh"

echo "Stamped version ${VERSION} in all files"

# --- 2. Build basic package at ../nats-channel ---

TARGET="../nats-channel"
rm -rf "$TARGET"
mkdir -p "$TARGET"/{src,shared,typings/openclaw/plugin-sdk,test}

# Files that don't change
cp index.ts setup-entry.ts tsconfig.json "$TARGET/"
cp shared/connection.ts "$TARGET/shared/"
cp -r typings/openclaw/plugin-sdk/*.d.ts "$TARGET/typings/openclaw/plugin-sdk/"

# Overlay: basic-specific files
cp basic/package.json "$TARGET/"
cp basic/openclaw.plugin.json "$TARGET/"
cp basic/shared/*.ts "$TARGET/shared/"
cp basic/src/*.ts "$TARGET/src/"
cp basic/test/*.ts "$TARGET/test/"

echo "Built basic package at $TARGET"

# --- 3. Create basic tarball ---

BASIC_TAR="$SCRIPT_DIR/nats-agents-basic-${VERSION}.tgz"
tar czf "$BASIC_TAR" -C "$(dirname "$TARGET")" "$(basename "$TARGET")" \
    --transform="s|^$(basename "$TARGET")|.|"

echo "Created $BASIC_TAR"

# --- 4. Create full tarball ---

FULL_TAR="$SCRIPT_DIR/nats-agents-${VERSION}.tgz"
tar czf "$FULL_TAR" \
    --exclude='install/*.tgz' \
    --exclude='basic' \
    package.json tsconfig.json README.md index.ts setup-entry.ts \
    openclaw.plugin.json shared/ src/ typings/ install/ test/

echo "Created $FULL_TAR"

# --- Done ---

echo ""
echo "=== Done ==="
echo "  Basic:  $BASIC_TAR"
echo "  Full:   $FULL_TAR"
echo "  Output: $TARGET"
echo ""
echo "  Upload both .tgz + openclaw.sh + openclaw-full.sh to https://m64.io/nats-channels/"
