import type { NatsConnection, Subscription } from "@nats-io/nats-core";
import { Svcm } from "@nats-io/services";
import type { ServiceHandler } from "@nats-io/services";
import type { AgentConfig, MessageHandler, StreamingMessageHandler, StreamResponder, RegisteredAgent } from "./types.js";
import { generateIdentity } from "./identity.js";
import type { AgentIdentity } from "./identity.js";
import {
  encryptMessage, decryptMessage,
  HEADER_SENDER_XKEY,
} from "./crypto.js";
import {
  AGENT_TYPE,
  DEFAULT_VERSION,
  buildInspectResponse,
  agentSubject,
  inspectSubject,
  parseEnvelope,
  toNatsHeaders,
  fromNatsHeaders,
} from "./protocol.js";

export async function registerAgent(
  nc: NatsConnection,
  config: AgentConfig,
  handler: MessageHandler | StreamingMessageHandler,
): Promise<RegisteredAgent> {
  const identity = generateIdentity();
  const version = config.version ?? DEFAULT_VERSION;

  const svc = new Svcm(nc);
  const service = await svc.add({
    name: config.name,
    version,
    description: config.description,
    metadata: {
      type: AGENT_TYPE,
      platform: config.platform,
      description: config.description,
      public_nkey: identity.publicNKey,
      public_xkey: identity.publicXKey,
      ...config.metadata,
    },
  });

  const encryptionEnabled = config.encryption === true;
  const isStreamingHandler = handler.length >= 2;

  const inboxHandler: ServiceHandler = (err, msg) => {
    if (err || !msg.reply) return;
    try {
      const hdrs = fromNatsHeaders(msg.headers);
      const isEncrypted = encryptionEnabled && Boolean(hdrs[HEADER_SENDER_XKEY]);

      let envelopeData: Uint8Array | string;
      let senderXKey: string | undefined;

      if (isEncrypted) {
        envelopeData = decryptMessage(msg.data, hdrs, identity.xkey);
        senderXKey = hdrs[HEADER_SENDER_XKEY];
      } else {
        envelopeData = msg.data;
      }

      const envelope = parseEnvelope(envelopeData);

      if (isStreamingHandler) {
        // Streaming handler: publish each chunk, then empty done signal
        const streamResponder: StreamResponder = {
          sendChunk(text: string) {
            nc.publish(msg.reply!, text);
          },
        };

        (handler as StreamingMessageHandler)(envelope, streamResponder).then(
          () => {
            // Empty payload = done
            nc.publish(msg.reply!, "");
          },
          (error) => msg.respondError(500, (error as Error).message),
        );
      } else {
        // Plain handler: publish response, then empty done signal
        (handler as MessageHandler)(envelope).then(
          (response) => {
            if (isEncrypted && senderXKey) {
              const encrypted = encryptMessage(
                new TextEncoder().encode(response),
                identity.xkey,
                senderXKey,
              );
              nc.publish(msg.reply!, encrypted.payload, { headers: toNatsHeaders(encrypted.headers) });
            } else {
              nc.publish(msg.reply!, response);
            }
            nc.publish(msg.reply!, "");
          },
          (error) => msg.respondError(500, (error as Error).message),
        );
      }
    } catch (e) {
      msg.respondError(400, (e as Error).message);
    }
  };

  service.addEndpoint("inbox", {
    subject: agentSubject(config.name, config.org),
    handler: inboxHandler,
  });

  const inspectSub: Subscription = nc.subscribe(inspectSubject(config.name, config.org), {
    callback: (_err, msg) => {
      const nonce = msg.data.length > 0 ? new TextDecoder().decode(msg.data) : undefined;
      const response = buildInspectResponse(config, identity, nonce);
      msg.respond(JSON.stringify(response));
    },
  });

  console.error(
    `[agent] registered "${config.name}" (${config.platform}) — subject: ${agentSubject(config.name, config.org)}`,
  );

  return {
    service,
    identity,
    stop: async () => {
      inspectSub.unsubscribe();
      await service.stop();
      console.error(`[agent] stopped "${config.name}"`);
    },
  };
}
