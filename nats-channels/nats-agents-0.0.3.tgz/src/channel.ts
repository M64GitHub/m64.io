import {
  createChatChannelPlugin,
  buildChannelOutboundSessionRoute,
  DEFAULT_ACCOUNT_ID,
} from "openclaw/plugin-sdk/core";
import type { ChannelPlugin, ChannelSetupWizard, OpenClawConfig } from "openclaw/plugin-sdk/core";
import { outboundSubject } from "../shared/index.js";
import { listNatsAccountIds, resolveNatsAccount } from "./accounts.js";
import { startNatsGateway, stopNatsGateway } from "./gateway.js";
import { createNatsAgentTools } from "./tools.js";
import { getActiveConnection, getActiveAgentName, getActiveIdentity, getActiveEncryption } from "./runtime.js";
import type { ResolvedNatsAccount } from "./types.js";

export const natsPlugin = createChatChannelPlugin<ResolvedNatsAccount>({
  base: {
    id: "nats",
    meta: {
      id: "nats",
      label: "NATS",
      selectionLabel: "NATS Agent Network",
      docsPath: "/channels/nats",
      blurb: "Connect agents via NATS messaging",
    },
    capabilities: {
      chatTypes: ["direct"],
      media: false,
      reactions: false,
      threads: false,
      polls: false,
      blockStreaming: true,
    },
    streaming: {
      blockStreamingCoalesceDefaults: {
        minChars: 100,
        idleMs: 500,
      },
    },
    setupWizard: {
      channel: "nats",
      status: {
        configuredLabel: "connected",
        unconfiguredLabel: "needs setup",
        configuredScore: 1,
        unconfiguredScore: 10,
        resolveConfigured: ({ cfg }: { cfg: OpenClawConfig }) =>
          listNatsAccountIds(cfg).some((id) => Boolean(resolveNatsAccount(cfg, id).agentName)),
      },
      credentials: [],
      textInputs: [
        {
          inputKey: "agentName",
          message: "Agent name (how this agent appears on the NATS network)",
          placeholder: "my-agent",
          required: true,
          currentValue: ({ cfg, accountId }: Record<string, unknown>) => {
            try {
              return resolveNatsAccount(cfg as OpenClawConfig, accountId as string).agentName || undefined;
            } catch { return undefined; }
          },
          validate: (value: string) => {
            if (!value) return "Agent name is required";
            if (!/^[-\w]+$/.test(value)) return "Only letters, numbers, dashes, and underscores allowed";
            return null;
          },
        },
        {
          inputKey: "description",
          message: "Description (shown when other agents discover you)",
          placeholder: "My OpenClaw agent",
          required: false,
          currentValue: ({ cfg, accountId }: Record<string, unknown>) => {
            try {
              return resolveNatsAccount(cfg as OpenClawConfig, accountId as string).description || undefined;
            } catch { return undefined; }
          },
        },
        {
          inputKey: "url",
          message: "NATS server URL",
          placeholder: "demo.nats.io",
          required: false,
          initialValue: () => "demo.nats.io",
          currentValue: ({ cfg, accountId }: Record<string, unknown>) => {
            try {
              return resolveNatsAccount(cfg as OpenClawConfig, accountId as string).url || undefined;
            } catch { return undefined; }
          },
        },
      ],
      finalize: async ({ cfg, accountId, prompter }: { cfg: OpenClawConfig; accountId: string; prompter: { confirm: (p: { message: string; initialValue?: boolean }) => Promise<boolean> } }) => {
        const current = resolveNatsAccount(cfg, accountId);
        const encryption = await prompter.confirm({
          message: "Enable end-to-end encryption?",
          initialValue: current.encryption,
        });
        const streaming = await prompter.confirm({
          message: "Enable streaming responses?",
          initialValue: current.streaming,
        });
        const raw = cfg as Record<string, unknown>;
        const channels = (raw.channels ?? {}) as Record<string, unknown>;
        const nats = (channels.nats ?? {}) as Record<string, unknown>;
        const accounts = (nats.accounts ?? {}) as Record<string, unknown>;
        const acct = (accounts[accountId] ?? {}) as Record<string, unknown>;
        acct.encryption = encryption;
        acct.streaming = streaming;
        return {
          cfg: { ...cfg, channels: { ...channels, nats: { ...nats, accounts: { ...accounts, [accountId]: acct } } } },
        };
      },
      completionNote: {
        title: "NATS Agent Ready",
        message: "Restart OpenClaw to connect. Your agent will be discoverable via 'nats micro list'.",
      },
    } as ChannelSetupWizard,
    config: {
      listAccountIds: (cfg: OpenClawConfig) => listNatsAccountIds(cfg),
      resolveAccount: (cfg: OpenClawConfig, accountId?: string | null) => resolveNatsAccount(cfg, accountId),
      isEnabled: (account: ResolvedNatsAccount) => account.enabled,
      isConfigured: (account: ResolvedNatsAccount) => Boolean(account.agentName),
      describeAccount: (account: ResolvedNatsAccount) => ({
        accountId: account.accountId,
        label: account.agentName,
        summary: `${account.agentName} @ ${account.url}`,
      }),
    },
    setup: {
      applyAccountConfig: ({ cfg, accountId, input }: { cfg: OpenClawConfig; accountId?: string; input: Record<string, unknown> }) => {
        const id = accountId ?? DEFAULT_ACCOUNT_ID;
        const raw = cfg as Record<string, unknown>;
        const channels = (raw.channels ?? {}) as Record<string, unknown>;
        const nats = (channels.nats ?? {}) as Record<string, unknown>;
        const accounts = (nats.accounts ?? {}) as Record<string, unknown>;
        accounts[id] = {
          ...(accounts[id] as Record<string, unknown> ?? {}),
          ...input,
        };
        return {
          ...cfg,
          channels: { ...channels, nats: { ...nats, accounts } },
        };
      },
    },
    gateway: {
      startAccount: startNatsGateway,
      stopAccount: stopNatsGateway,
    },
    messaging: {
      normalizeTarget: (raw: string) => raw.replace(/^nats:/i, ""),
      inferTargetChatType: () => "direct",
      resolveOutboundSessionRoute: (params: Record<string, unknown>) =>
        buildChannelOutboundSessionRoute({
          cfg: params.cfg as OpenClawConfig,
          agentId: (params.agentId as string) ?? "main",
          channel: "nats",
          accountId: params.accountId as string | undefined,
          peer: { kind: "direct", id: (params.to as string) ?? "unknown" },
          chatType: "direct",
          from: `nats:${(params.to as string) ?? "unknown"}`,
          to: `nats:${(params.to as string) ?? "unknown"}`,
        }),
    },
    agentTools: () => createNatsAgentTools(getActiveConnection, getActiveAgentName, getActiveIdentity, getActiveEncryption),
  },
  // Open security: all NATS senders allowed, no pairing
  security: {
    dm: {
      channelKey: "nats",
      resolvePolicy: () => "allow",
      resolveAllowFrom: () => undefined,
    },
  },
  outbound: {
    base: {
      deliveryMode: "direct",
      textChunkLimit: 1024 * 1024,
      sendText: async (ctx: Record<string, unknown>) => {
        const nc = getActiveConnection();
        const agentName = getActiveAgentName();
        if (!nc || !agentName) {
          return [{ success: false, error: "NATS not connected" } as Record<string, unknown>];
        }
        const text = typeof ctx.text === "string" ? ctx.text : String(ctx.text);
        nc.publish(outboundSubject(agentName), text);
        return [{ success: true } as Record<string, unknown>];
      },
    },
  },
}) as ChannelPlugin;
