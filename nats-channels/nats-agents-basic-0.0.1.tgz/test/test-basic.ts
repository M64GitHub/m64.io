import { Svcm } from "@nats-io/services";
import { connectToNats, drainConnection } from "../shared/connection.js";
import { registerAgent } from "../shared/micro.js";
import {
  agentSubject,
  inspectSubject,
  buildEnvelope,
  HEADER_STREAM,
  HEADER_STREAM_STATUS,
  STREAM_ACCEPT,
  STREAM_STATUS_DONE,
  AGENT_TYPE,
  toNatsHeaders,
} from "../shared/protocol.js";
import type { MessageEnvelope, StreamResponder, InspectResponse } from "../shared/types.js";

let passed = 0;
let failed = 0;

function assert(condition: boolean, label: string) {
  if (condition) {
    console.log(`  \u2713 ${label}`);
    passed++;
  } else {
    console.log(`  \u2717 ${label}`);
    failed++;
  }
}

async function main() {
  console.log("\n--- NATS Channel Basic Test ---\n");

  // Connect
  const nc = await connectToNats();

  // Register a plaintext agent
  const agent = await registerAgent(
    nc,
    {
      name: "test-basic",
      description: "A basic test agent",
      platform: "test",
      metadata: { environment: "testing" },
    },
    async (envelope) => {
      return `echo: ${envelope.body}`;
    },
  );

  // Register a streaming agent
  const streamAgent = await registerAgent(
    nc,
    {
      name: "test-basic-stream",
      description: "A streaming test agent",
      platform: "test",
    },
    async (envelope: MessageEnvelope, stream: StreamResponder) => {
      const words = envelope.body.split(" ");
      for (const word of words) {
        stream.sendChunk(word + " ");
      }
      return `echo: ${envelope.body}`;
    },
  );

  await new Promise((r) => setTimeout(r, 500));

  // Test 1: Discovery via NATS service ping
  console.log("\n[Test] Discovery");
  const svc = new Svcm(nc);
  const client = svc.client({ strategy: "stall" as never, maxWait: 3000 });
  const allPings: Array<{ name: string; metadata?: Record<string, string> }> = [];
  for await (const p of await client.ping()) {
    allPings.push(p);
  }
  const agentPings = allPings.filter((p) => p.metadata?.type === AGENT_TYPE);
  const found = agentPings.find((p) => p.name === "test-basic");
  assert(found !== undefined, "test-basic discovered via service ping");
  assert(found?.metadata?.platform === "test", "platform metadata correct");
  assert(found?.metadata?.type === "agent", 'metadata.type is "agent"');
  assert(found?.metadata?.environment === "testing", "custom metadata preserved");

  // Test 2: INSPECT
  console.log("\n[Test] Inspect");
  const inspectReply = await nc.request(inspectSubject("test-basic"), "");
  const info: InspectResponse = JSON.parse(new TextDecoder().decode(inspectReply.data));
  assert(info.name === "test-basic", "inspect returns correct name");
  assert(info.capabilities.length === 2, "two capabilities (prompt + notifications)");
  const promptCap = info.capabilities.find((c) => c.name === "prompt");
  assert(promptCap?.pattern === "request/reply", "prompt capability is request/reply");
  assert(promptCap?.endpoint === "agents.oc.test-basic", "prompt endpoint correct");
  assert(promptCap?.streaming === true, "streaming advertised");

  // Test 3: Send message (plaintext request/reply)
  console.log("\n[Test] Messaging (plaintext)");
  const payload = buildEnvelope("tester", "hello world");
  const reply = await nc.request(agentSubject("test-basic"), payload);
  const response = new TextDecoder().decode(reply.data);
  assert(response === "echo: hello world", "plaintext echo response matches");

  // Test 4: Streaming response
  console.log("\n[Test] Streaming");
  const streamPayload = buildEnvelope("tester", "hello world");
  const chunks: string[] = [];
  const inbox = nc.subscribe(nc.info?.client_id ? `_INBOX.${Date.now()}` : `_INBOX.${Math.random().toString(36).slice(2)}`);
  const streamHdrs = toNatsHeaders({ [HEADER_STREAM]: STREAM_ACCEPT });
  nc.publish(agentSubject("test-basic-stream"), streamPayload, { reply: inbox.getSubject(), headers: streamHdrs });
  const streamTimeout = setTimeout(() => inbox.unsubscribe(), 5000);
  for await (const msg of inbox) {
    const text = new TextDecoder().decode(msg.data);
    const status = msg.headers?.get(HEADER_STREAM_STATUS);
    if (text) chunks.push(text);
    if (status === STREAM_STATUS_DONE) break;
  }
  clearTimeout(streamTimeout);
  const accumulated = chunks.join("");
  assert(accumulated === "hello world ", "streaming accumulated response matches");
  assert(chunks.length >= 2, `received ${chunks.length} chunks (expected >=2 for 'hello world')`);
  assert(chunks.some((c) => c.includes("hello")), "chunks contain 'hello'");

  // Test 5: Org namespace
  console.log("\n[Test] Org namespace");
  const orgAgent = await registerAgent(
    nc,
    {
      name: "test-basic-org",
      description: "An org-scoped agent",
      platform: "test",
      org: "testns",
    },
    async (envelope) => `echo: ${envelope.body}`,
  );
  await new Promise((r) => setTimeout(r, 300));

  const orgInspectReply = await nc.request(inspectSubject("test-basic-org", "testns"), "");
  const orgInfo: InspectResponse = JSON.parse(new TextDecoder().decode(orgInspectReply.data));
  assert(orgInfo.name === "test-basic-org", "org agent: inspect works with org prefix");
  const orgPrompt = orgInfo.capabilities.find((c) => c.name === "prompt");
  assert(orgPrompt?.endpoint === "agents.oc.testns.test-basic-org", "org agent: endpoint includes org prefix");

  const orgPayload = buildEnvelope("tester", "org test");
  const orgReply = await nc.request(agentSubject("test-basic-org", "testns"), orgPayload);
  assert(new TextDecoder().decode(orgReply.data) === "echo: org test", "org agent: messaging works with org prefix");

  await orgAgent.stop();

  // Cleanup
  await agent.stop();
  await streamAgent.stop();
  await drainConnection(nc);

  // Summary
  console.log(`\n--- Results: ${passed} passed, ${failed} failed ---\n`);
  process.exit(failed > 0 ? 1 : 0);
}

main().catch((err) => {
  console.error("Test failed:", err);
  process.exit(1);
});
