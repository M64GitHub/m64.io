# End-to-End Encryption

## Why

NATS routes messages — it doesn't read them. But by default, payloads are plaintext. Anyone with access to the NATS server (operators, monitoring tools, other subscribers) can read agent-to-agent messages.

End-to-end encryption ensures that only the intended sender and recipient can read message payloads. The NATS server, any intermediary, and any subscriber without the right keys sees only encrypted bytes.

*"Zero Trust — even the system routing your messages can't read them."*

## Enabling Encryption

Encryption is **off by default**. To enable, set `"encryption": true` in your NATS account config:

```json
{
  "channels": {
    "nats": {
      "accounts": {
        "default": {
          "agentName": "my-agent",
          "url": "nats://localhost:4222",
          "encryption": true
        }
      }
    }
  }
}
```

When disabled, agents communicate in plaintext — useful for development and testing with the `nats` CLI. Identity keys are still generated (for INSPECT nonce verification), but message payloads are not encrypted.

The INSPECT response includes an `encryption` field so callers can discover whether an agent supports encrypted messaging.

## Scheme: Hybrid Encryption

Each message uses **two layers** of encryption:

1. **AES-256-GCM** (symmetric) — encrypts the actual payload. Fast, authenticated.
2. **Curve25519 NaCl box** (asymmetric) — seals the AES key for the specific recipient.

This hybrid approach gives us the speed of symmetric encryption with the key-exchange properties of asymmetric crypto.

## Identity: Two Key Pairs

Every agent generates two key pairs on startup:

| Key | Type | Purpose | Prefix |
|-----|------|---------|--------|
| **NKey** | Ed25519 | Signing, identity verification | `U...` |
| **XKey** | Curve25519 | Encryption, key exchange | `X...` |

Both are provided by `@nats-io/nkeys` — the same library NATS uses for its own authentication.

**Keys are ephemeral** — generated fresh on every startup, not persisted to disk. Each session gets a new identity. This provides forward secrecy at the session level.

> **TODO:** Add optional key persistence for stable identity across restarts. This is needed for production use where agents need to be recognized by their public keys.

## Wire Format

### Encrypted Payload

```
[IV (12 bytes)][ciphertext (variable)][auth tag (16 bytes)]
```

- **IV**: Random 12-byte initialization vector (unique per message)
- **Ciphertext**: AES-256-GCM encrypted payload
- **Auth tag**: 16-byte GCM authentication tag (detects tampering)

### NATS Headers

Two headers are added to every encrypted message:

```
Synadia-Sym-Key: <base64-encoded sealed AES key>
Synadia-Sender-Xkey: <sender's public XKey>
```

- `Synadia-Sym-Key`: The random AES-256 key, sealed using NaCl box with the sender's private XKey and the recipient's public XKey. Only the intended recipient can unseal it.
- `Synadia-Sender-Xkey`: The sender's public Curve25519 key. The recipient needs this to open the sealed symmetric key.

## Message Flow

### Sending an encrypted message

```
1. Sender looks up recipient's public XKey
   → calls agents.{name}.inspect (INSPECT endpoint)
   → gets { identity: { publicXKey: "X..." } }

2. Sender generates a fresh random AES-256 key (32 bytes) + IV (12 bytes)

3. Sender encrypts the payload with AES-256-GCM
   → plaintext envelope → [IV][ciphertext][auth tag]

4. Sender seals the AES key using NaCl box
   → seal(aesKey, senderPrivateXKey, recipientPublicXKey)
   → base64-encode → Synadia-Sym-Key header

5. Sender publishes to NATS with encrypted payload + headers
```

### Receiving and decrypting

```
1. Recipient reads Synadia-Sender-Xkey header → sender's public XKey

2. Recipient reads Synadia-Sym-Key header → base64 decode → sealed AES key

3. Recipient opens the sealed key using NaCl box
   → open(sealedKey, recipientPrivateXKey, senderPublicXKey)
   → recovers the random AES-256 key

4. Recipient decrypts payload with AES-256-GCM
   → [IV][ciphertext][auth tag] → plaintext envelope

5. If the auth tag doesn't match → reject (tampered)
   If the sealed key can't be opened → reject (wrong recipient or tampered)
```

### Response encryption (same process, reversed roles)

```
1. Agent reads sender's public XKey from the request's Synadia-Sender-Xkey header
2. Agent encrypts the response for the sender (using sender's XKey as recipient)
3. Agent responds on the NATS reply subject with encrypted payload + headers
4. Original sender decrypts using their own XKey
```

## Identity Verification (Nonce Challenge)

Encryption ensures only the right agent can read a message. But how do you know you're encrypting for the right agent? An attacker could register a fake micro service and advertise their own XKey.

**Nonce verification** solves this. When a client calls INSPECT:

```
1. Client generates a random nonce (UUID)
2. Client sends nonce as the INSPECT request payload
3. Agent signs the nonce with its NKey (Ed25519 private key)
4. Agent returns the signature in the INSPECT response
5. Client verifies the signature against the agent's advertised public NKey
```

If the signature verifies, the agent provably holds the private NKey — it's not impersonating. The `verified: true` flag is set on the response.

This happens automatically when `getAgentInfo` or `sendToAgent` is called with an identity. The INSPECT round-trip does double duty: fetch the XKey for encryption AND verify the NKey for identity.

## What Stays Unencrypted

| Subject | Encrypted? | Reason |
|---------|-----------|--------|
| `$SRV.PING/INFO/STATS` | No | Standard NATS micro discovery — public |
| `agents.{name}.inspect` | No | Public capability advertisement — agents need to find each other's XKeys |
| `agents.{name}.inbox` | **Yes** | Agent-to-agent message payloads |
| `agents.{name}.outbound` | No (v1) | Broadcast notifications — encrypt per-subscriber in future |

Discovery and INSPECT are intentionally public. An agent needs to know another agent's public XKey before it can send an encrypted message. The XKey itself is not secret — it's a public key.

## Key Exchange

There is no explicit key exchange step. The protocol is:

1. Discover agents via `$SRV.PING` (get names)
2. INSPECT the target agent (get their public XKey)
3. Encrypt with their public XKey, send

This means `sendToAgent` does **two round trips** per call: one INSPECT to get the XKey, then the encrypted message. This is acceptable for v1.

> **Future optimization:** Cache known XKeys after first INSPECT. Invalidate on reconnect or when the agent re-registers (new session = new keys).

## Crypto Properties

- **Confidentiality**: AES-256-GCM — only the holder of the symmetric key can read the payload
- **Authenticity**: GCM auth tag — any modification to the ciphertext is detected
- **Sender authentication**: NaCl box seal — only the claimed sender could have sealed the key
- **Forward secrecy (session-level)**: Fresh keys per startup — compromise of current keys doesn't expose past sessions
- **Fresh key per message**: Random AES key + IV per message — identical plaintexts produce different ciphertexts

## Dependencies

- `@nats-io/nkeys` — NKey (Ed25519) and XKey (Curve25519) generation, seal/open
- Node.js `crypto` — AES-256-GCM (createCipheriv/createDecipheriv, randomBytes)

No additional dependencies. The crypto primitives are standard (NIST AES-GCM, DJB Curve25519, Ed25519).

## Code

The encryption implementation is in `shared/crypto.ts` (~85 lines), adopted from [synadia-io/agent-js](https://github.com/synadia-io/agent-js).

Key generation is in `shared/identity.ts` — `generateIdentity()` returns an `AgentIdentity` with both NKey and XKey pairs.

The `registerAgent` function in `shared/micro.ts` automatically handles encryption when `config.encryption` is `true`: if the incoming message has crypto headers, it decrypts before processing and encrypts the response. When encryption is disabled (the default), crypto is bypassed entirely — all messages are treated as plaintext.
