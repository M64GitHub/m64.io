import type { NatsConnection } from "@nats-io/nats-core";
import { Svcm } from "@nats-io/services";
import { randomUUID } from "crypto";
import type { AgentInfo, InspectResponse } from "./types.js";
import type { AgentIdentity } from "./identity.js";
import {
  encryptMessage, decryptMessage,
  encryptMessageRetainingSession, decryptChunk,
  type SessionKeyMaterial,
} from "./crypto.js";
import {
  AGENT_TYPE,
  HEADER_STREAM,
  HEADER_STREAM_STATUS,
  HEADER_CRYPTO_MODE,
  STREAM_ACCEPT,
  STREAM_STATUS_DONE,
  CRYPTO_MODE_STREAM,
  buildEnvelope,
  inboxSubject,
  inspectSubject,
  toNatsHeaders,
  fromNatsHeaders,
} from "./protocol.js";

const DEFAULT_DISCOVERY_TIMEOUT = 3000;
const DEFAULT_AGENT_TIMEOUT = 120_000;

export async function discoverAgents(
  nc: NatsConnection,
  timeout: number = DEFAULT_DISCOVERY_TIMEOUT,
): Promise<AgentInfo[]> {
  const svc = new Svcm(nc);
  const client = svc.client({ strategy: "stall", maxWait: timeout });
  const pings = await client.ping();

  const agents: AgentInfo[] = [];
  for await (const identity of pings) {
    if (identity.metadata?.type !== AGENT_TYPE) continue;
    agents.push({
      name: identity.name,
      id: identity.id,
      version: identity.version,
      description: identity.metadata.description ?? "",
      platform: identity.metadata.platform ?? "unknown",
      metadata: identity.metadata,
    });
  }

  return agents;
}

export async function getAgentInfo(
  nc: NatsConnection,
  name: string,
  opts?: {
    timeout?: number;
    identity?: AgentIdentity;
    org?: string;
  },
): Promise<InspectResponse> {
  const timeout = opts?.timeout ?? DEFAULT_DISCOVERY_TIMEOUT;
  const nonce = randomUUID();
  const msg = await nc.request(inspectSubject(name, opts?.org), nonce, { timeout });
  const info = JSON.parse(msg.string()) as InspectResponse;

  // Verify the agent signed our nonce (proves key ownership)
  if (opts?.identity) {
    info.verified = opts.identity.verify(nonce, info.identity.signature, info.identity.publicNKey);
  }

  return info;
}

/**
 * Send a message to another agent and get the response.
 * When identity is provided, the message is end-to-end encrypted:
 * 1. INSPECT the target to get their public XKey (extra round-trip)
 * 2. Encrypt the envelope with AES-256-GCM + sealed symmetric key
 * 3. Decrypt the response
 * TODO: Cache known XKeys to avoid the INSPECT round-trip on every send.
 */
export async function sendToAgent(
  nc: NatsConnection,
  senderName: string,
  targetName: string,
  message: string,
  opts?: {
    timeout?: number;
    identity?: AgentIdentity;
    encryption?: boolean;
    org?: string;
  },
): Promise<string> {
  const timeout = opts?.timeout ?? DEFAULT_AGENT_TIMEOUT;
  const identity = opts?.identity;
  const encryption = opts?.encryption === true;
  const org = opts?.org;
  const envelopeStr = buildEnvelope(senderName, message);

  if (identity && encryption) {
    // Encrypted path: get target's XKey + verify identity, encrypt, send, decrypt response
    const info = await getAgentInfo(nc, targetName, { identity, org });
    const targetXKey = info.identity.publicXKey;

    const encrypted = encryptMessage(
      new TextEncoder().encode(envelopeStr),
      identity.xkey,
      targetXKey,
    );

    const msg = await nc.request(inboxSubject(targetName, org), encrypted.payload, {
      timeout,
      headers: toNatsHeaders(encrypted.headers),
    });

    const responseHdrs = fromNatsHeaders(msg.headers);
    const decrypted = decryptMessage(msg.data, responseHdrs, identity.xkey);
    return new TextDecoder().decode(decrypted);
  }

  // Plaintext path (backward compat)
  const msg = await nc.request(inboxSubject(targetName, org), envelopeStr, { timeout });
  return msg.string();
}

const DEFAULT_STALL_MS = 5000;

/**
 * Send a message to another agent and receive a streaming response.
 * Uses requestMany() with stall strategy to collect chunks.
 * Falls back to single-shot if the target doesn't advertise streaming.
 */
export async function sendToAgentStreaming(
  nc: NatsConnection,
  senderName: string,
  targetName: string,
  message: string,
  opts?: {
    timeout?: number;
    identity?: AgentIdentity;
    encryption?: boolean;
    org?: string;
    stallMs?: number;
    onChunk?: (text: string, info: { seq: number; done: boolean }) => void;
  },
): Promise<string> {
  const timeout = opts?.timeout ?? DEFAULT_AGENT_TIMEOUT;
  const identity = opts?.identity;
  const encryption = opts?.encryption === true;
  const org = opts?.org;
  const stallMs = opts?.stallMs ?? DEFAULT_STALL_MS;
  const envelopeStr = buildEnvelope(senderName, message);

  // Check if target supports streaming
  const info = identity
    ? await getAgentInfo(nc, targetName, { identity, org })
    : await getAgentInfo(nc, targetName, { org });

  const promptCap = info.capabilities.find((c) => c.name === "prompt");
  if (!promptCap?.streaming) {
    // Fallback to single-shot
    return sendToAgent(nc, senderName, targetName, message, opts);
  }

  // Build request with stream header
  const streamHdrs: Record<string, string> = { [HEADER_STREAM]: STREAM_ACCEPT };
  let session: SessionKeyMaterial | undefined;

  let payload: Uint8Array | string;
  if (identity && encryption) {
    const encrypted = encryptMessageRetainingSession(
      new TextEncoder().encode(envelopeStr),
      identity.xkey,
      info.identity.publicXKey,
    );
    payload = encrypted.payload;
    Object.assign(streamHdrs, encrypted.headers);
    session = encrypted.session;
  } else {
    payload = envelopeStr;
  }

  const iter = await nc.requestMany(inboxSubject(targetName, org), payload, {
    strategy: "stall",
    stall: stallMs,
    maxWait: timeout,
    headers: toNatsHeaders(streamHdrs),
  });

  let accumulated = "";
  for await (const msg of iter) {
    const hdrs = fromNatsHeaders(msg.headers);
    const status = hdrs[HEADER_STREAM_STATUS];
    const seq = parseInt(hdrs["Nats-Agent-Stream-Seq"] ?? "0", 10);
    const done = status === STREAM_STATUS_DONE;

    let text: string;
    if (session && hdrs[HEADER_CRYPTO_MODE] === CRYPTO_MODE_STREAM) {
      text = new TextDecoder().decode(decryptChunk(session, seq, msg.data));
    } else {
      text = new TextDecoder().decode(msg.data);
    }

    if (done) {
      opts?.onChunk?.(text, { seq, done: true });
      return accumulated;
    }

    accumulated += text;
    opts?.onChunk?.(text, { seq, done: false });
  }

  return accumulated;
}
