import type { OpenClawConfig } from "openclaw/plugin-sdk/core";
import { DEFAULT_ACCOUNT_ID } from "openclaw/plugin-sdk/core";
import type { NatsAccountConfig, ResolvedNatsAccount } from "./types.js";

function getNatsConfig(cfg: OpenClawConfig): Record<string, unknown> {
  return (cfg as Record<string, unknown>).channels as Record<string, unknown> ?? {};
}

function getNatsChannelConfig(cfg: OpenClawConfig): Record<string, unknown> {
  const channels = getNatsConfig(cfg);
  return (channels as Record<string, unknown>).nats as Record<string, unknown> ?? {};
}

function getAccounts(cfg: OpenClawConfig): Record<string, NatsAccountConfig> {
  const nats = getNatsChannelConfig(cfg);
  return (nats as Record<string, Record<string, NatsAccountConfig>>).accounts ?? {};
}

export function listNatsAccountIds(cfg: OpenClawConfig): string[] {
  return Object.keys(getAccounts(cfg));
}

export function resolveNatsAccount(
  cfg: OpenClawConfig,
  accountId?: string | null,
): ResolvedNatsAccount {
  const id = accountId ?? DEFAULT_ACCOUNT_ID;
  const accounts = getAccounts(cfg);
  const raw = accounts[id] ?? {} as NatsAccountConfig;

  const resolved: ResolvedNatsAccount = {
    accountId: id,
    enabled: raw.enabled !== false,
    url: raw.url ?? "",
    agentName: raw.agentName ?? "",
    description: raw.description ?? "",
    credentials: raw.credentials,
    encryption: raw.encryption === true,
    org: raw.org || undefined,
    config: raw,
  };

  // Environment variable overrides (for Docker/container deployments)
  const env = process.env;
  if (env.NATS_URL) resolved.url = env.NATS_URL;
  if (env.NATS_AGENT_NAME) resolved.agentName = env.NATS_AGENT_NAME;
  if (env.NATS_DESCRIPTION) resolved.description = env.NATS_DESCRIPTION;
  if (env.NATS_ORG) resolved.org = env.NATS_ORG;
  if (env.NATS_CREDENTIALS) resolved.credentials = env.NATS_CREDENTIALS;
  if (env.NATS_ENCRYPTION) resolved.encryption = env.NATS_ENCRYPTION === "true";

  return resolved;
}
