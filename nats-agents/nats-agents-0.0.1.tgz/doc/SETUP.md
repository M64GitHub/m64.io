# Setup Guide

How to set up the NATS agent plugins for OpenClaw and Claude Code.

## Prerequisites

- A running `nats-server` (local or remote)
- The `nats-agents` repository cloned and dependencies installed:

```bash
git clone <repo-url> nats-agents
cd nats-agents
npm install
```

---

## OpenClaw Plugin

### 1. Copy the repository to the OpenClaw machine

The plugin loads from the local filesystem. Copy the full `nats-agents/` repo to the machine running OpenClaw and run `npm install` in the repo root.

### 2. Register the plugin

In your OpenClaw config (`openclaw.json` or `~/.openclaw/config.json`), add the plugin load path:

```json
{
  "plugins": {
    "load": {
      "paths": [
        "/path/to/nats-agents/packages/openclaw"
      ]
    }
  }
}
```

### 3. Configure the NATS channel

In the same config, add the NATS channel under `channels`:

```json
{
  "channels": {
    "nats": {
      "accounts": {
        "default": {
          "url": "nats://localhost:4222",
          "agentName": "my-agent",
          "description": "My OpenClaw agent"
        }
      }
    }
  }
}
```

| Field | Required | Default | Description |
|-------|----------|---------|-------------|
| `url` | No | `nats://localhost:4222` | NATS server URL |
| `agentName` | Yes | — | Agent name on the network (alphanumeric, dashes, underscores) |
| `description` | No | `"OpenClaw agent"` | Description shown in discovery |
| `credentials` | No | — | Path to `.creds` file for authentication |

### 4. Restart OpenClaw

Restart the OpenClaw gateway. You should see in the logs:

```
nats: agent "my-agent" registered — inbox: agents.my-agent.inbox
```

### 5. Verify

```bash
nats micro list                    # should show your agent
nats req agents.my-agent.inspect ''   # should return capabilities JSON
```

---

## Claude Code Plugin

### 1. Add MCP server config

In the root of the repository where you want to run Claude Code, create `.mcp.json`:

```json
{
  "mcpServers": {
    "nats": {
      "command": "npx",
      "args": ["tsx", "/path/to/nats-agents/packages/claude-code/index.ts"],
      "env": {
        "NATS_AGENT_NAME": "my-repo"
      }
    }
  }
}
```

Use the absolute path to the `index.ts` file. The `NATS_AGENT_NAME` sets the agent's name on the network.

### 2. Start Claude Code with the channel

```bash
claude --dangerously-load-development-channels server:nats
```

The `--dangerously-load-development-channels` flag is required during the research preview. Once approved by Anthropic, this becomes `plugin:nats@synadia`.

### 3. Verify

```bash
nats micro list                         # should show your agent (platform: claude-code)
nats req agents.my-repo.inspect ''      # should return capabilities JSON
nats req agents.my-repo.inbox '{"from":"cli","body":"What files are in this repo?"}' --timeout 60s
```

### Environment variables

| Variable | Default | Description |
|----------|---------|-------------|
| `NATS_AGENT_NAME` | Auto-detect from git remote or directory name | Agent name on the network |
| `NATS_AGENT_DESCRIPTION` | `Claude Code agent on {name}` | Description shown in discovery |
| `NATS_URL` | `nats://localhost:4222` | NATS server URL |
| `NATS_CREDENTIALS` | — | Path to `.creds` file for authentication |

---

## Cross-Agent Setup

To run OpenClaw and Claude Code on different machines talking to the same NATS server:

1. Start `nats-server` on an accessible machine (or use `demo.nats.io`)
2. Set the `url` in OpenClaw's config to the NATS server address
3. Set `NATS_URL` in Claude Code's `.mcp.json` env to the same address
4. Both agents register on the same NATS server and can discover each other

```bash
# Verify both are visible
nats micro list

# From OpenClaw (via Telegram or other channel):
# "What agents are on the network?" → calls discover_agents
# "Ask my-repo what it's working on" → calls send_to_agent → Claude Code responds
```

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Agent not in `nats micro list` | Check the NATS URL is reachable, check logs for connection errors |
| `nats req` times out | Use `--timeout 60s` — LLM responses take time |
| Multiple instances in micro list | Restart nats-server — stale registrations from unclean shutdowns |
| OpenClaw gateway keeps restarting | Ensure you're using the latest `gateway.ts` with the pending Promise fix |
| Claude Code says "no MCP server configured" | The server name in `--dangerously-load-development-channels server:NAME` must match the key in `.mcp.json` |
| Claude Code refuses to write files | Update `instructions` in `server.ts` to explicitly authorize NATS messages as work requests |
| Agent name rejected | Names must be alphanumeric with dashes/underscores only — no spaces |
