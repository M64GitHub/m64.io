# nats-agents

**Connect any AI agent to NATS — discoverable, addressable, composable.**

---

## What is this?

nats-agents makes AI agents first-class citizens on [NATS](https://nats.io). Install a plugin, and your agent becomes discoverable by other agents, addressable via NATS messaging, and capable of finding and communicating with other agents on the network.

No framework. No orchestrator. No protocol to implement. Just NATS.

## Quick start

```bash
git clone <repo-url> nats-agents && cd nats-agents
npm install
nats-server &                # start a local NATS server
npx tsx demo-agent.ts        # register an echo agent
```

In another terminal:

```bash
nats micro list              # see the agent on the network
nats req agents.demo-agent.inbox '{"from":"cli","body":"hello"}' --timeout 30s
```

For OpenClaw and Claude Code integration, see [doc/SETUP.md](doc/SETUP.md).

## The problem

AI agents today are islands. Claude Code runs in a terminal. OpenClaw runs on a server. Other agents run elsewhere. They can't find each other, can't talk to each other, and can't coordinate — unless someone builds a bridge between every pair.

Existing solutions (Google A2A, MCP) try to solve this by defining rigid protocols with discovery schemas, capability negotiation, and structured message formats. They bake in too much semantics too early.

## The approach

nats-agents treats NATS as the substrate — connectivity, security, and basic addressing. Agents figure out the rest.

An agent with nats-agents installed:

1. **Is discoverable.** Registers as a NATS micro service. Any NATS client can find it with `nats micro list`.

2. **Is addressable.** Listens on `agents.{name}.inbox` for prompts via standard NATS request/reply.

3. **Can find others.** The plugin provides tools (`discover_agents`, `send_to_agent`) that the agent's LLM can call to discover and communicate with other agents on the network.

4. **Can speak unprompted.** Publishes cron results, notifications, and alerts to `agents.{name}.outbound` for anyone subscribed.

All of this happens over a single NATS connection. No sidecar, no separate service, no additional credentials.

## How it works

```
                        NATS
                         │
          ┌──────────────┼──────────────┐
          │              │              │
     ┌────┴────┐   ┌─────┴────┐   ┌─────┴────┐
     │ OpenClaw│   │ Claude   │   │ Claude   │
     │  "sre"  │   │  Code    │   │  Code    │
     │         │   │"nats-zig"│   │"frontend"│
     └─────────┘   └──────────┘   └──────────┘

  nats micro list:
    sre          (OpenClaw)     "Infrastructure SRE agent"
    nats-zig     (Claude Code)  "NATS Zig client development"
    frontend     (Claude Code)  "React dashboard"
```

Each agent registers as a NATS micro service with metadata identifying it as an agent. Discovery is built into NATS — no registry server, no service mesh. The micro framework uses standard NATS request/reply on well-known subjects (`$SRV.PING`, `$SRV.INFO`).

When an agent wants to talk to another agent, it uses the tools the plugin provides:

```
User on Telegram → OpenClaw:
  "Ask the nats-zig agent about the KV store progress"

OpenClaw calls discover_agents() → finds nats-zig
OpenClaw calls send_to_agent("nats-zig", "What's the KV store status?")
  → NATS request to agents.nats-zig.inbox
  → Claude Code (in the nats.zig repo) responds
  → OpenClaw relays the answer to Telegram
```

No hardcoded addresses. No routing table. The agent discovered the other agent at runtime and communicated through NATS.

## Subject convention

```
agents.{name}.inbox      ← request/reply — send prompts, get responses
agents.{name}.outbound   ← pub/sub — agent-initiated messages (cron, alerts)
agents.{name}.inspect    ← request/reply — "tell me what you can do"
```

## Try it

With a NATS server running and an agent registered:

```bash
# Who's on the network?
nats micro list

# What can this agent do?
nats req agents.mario-sre.inspect ''

# Send a prompt (use --timeout for LLM response time)
nats req agents.mario-sre.inbox '{"from":"cli","body":"What are you working on?"}' --timeout 30s

# Subscribe to agent notifications
nats sub agents.mario-sre.outbound
```

### Agent-to-agent demo

Start a local echo agent alongside any platform agent (OpenClaw, Claude Code, etc.):

```bash
nats-server &
npx tsx demo-agent.ts &    # registers "demo-agent", echoes messages
# ... start your platform agent (e.g. OpenClaw with NATS plugin)
```

Both agents appear on the network:

```
❯ nats micro list
╭──────────────────────────────────────────────────────────────╮
│                         All Services                         │
├────────────┬─────────┬──────────┬────────────────────────────┤
│ Name       │ Version │ ID       │ Description                │
├────────────┼─────────┼──────────┼────────────────────────────┤
│ Echo128    │ 1.0.0   │ NW60M... │ SRE agent                  │
│ demo-agent │ 1.0.0   │ RRH7P... │ A demo agent that echoes   │
╰────────────┴─────────┴──────────┴────────────────────────────╯
```

Tell your agent to discover and talk to the other one. Here's what happens on the wire:

```
❯ nats sub "agents.demo-agent.>"

Received on "agents.demo-agent.inbox":
{"from":"Echo128","body":"Hey demo-agent! Just wanted to say hello —
first A2A contact over NATS. How are you doing?"}
```

The demo agent logs the message and echoes it back:

```
[demo] received from "Echo128": Hey demo-agent! Just wanted to say
hello — first A2A contact over NATS. How are you doing?
```

No routing table. No orchestrator. Two agents found each other and talked — through NATS.

## Platform support

nats-agents ships channel plugins for agent platforms. Each plugin handles the full lifecycle on one NATS connection: connect, register, receive prompts, send responses, expose agent tools.

| Platform | Type | Status |
|----------|------|--------|
| OpenClaw | TypeScript channel plugin | Working |
| Claude Code | TypeScript MCP server | Working |
| Generic (PI Agent, others) | Sidecar / webhook bridge | Future |

### OpenClaw

The OpenClaw plugin integrates as a native channel — like Telegram, Discord, or WhatsApp, but for NATS. Messages from NATS arrive in the agent's main session with full personality, memory, and tools. The plugin also registers agent tools (`discover_agents`, `agent_info`, `send_to_agent`) so the LLM can actively discover and communicate with other agents.

### Claude Code

The Claude Code plugin is an MCP server that pushes NATS events into the running session. Each Claude Code instance is project-bound — tied to a specific codebase. Multiple instances can run simultaneously, each discoverable as a separate agent with repo metadata.

## Discovery protocol

Agents register as NATS micro services with agent-specific metadata:

```json
{
  "name": "mario-sre",
  "id": "Xk7i4K7FKIuiivKgSB8VWyj",
  "version": "1.0.0",
  "metadata": {
    "type": "agent",
    "platform": "openclaw",
    "description": "Infrastructure SRE agent"
  }
}
```

The INSPECT endpoint returns capabilities — what the agent can do and how to interact with it:

```json
{
  "name": "mario-sre",
  "description": "Infrastructure SRE agent — investigates incidents, fixes configs",
  "capabilities": [
    {
      "name": "prompt",
      "endpoint": "agents.mario-sre.inbox",
      "description": "Send a prompt and receive a response.",
      "pattern": "request/reply"
    },
    {
      "name": "notifications",
      "endpoint": "agents.mario-sre.outbound",
      "description": "Subscribe to receive cron reports and alerts.",
      "pattern": "pub/sub"
    }
  ]
}
```

Capabilities are LLM-friendly by design — an agent reading this response knows exactly how to interact with the other agent.

## Architecture

```
nats-agents/
├── shared/              ← common NATS logic (connection, micro, discovery, protocol)
├── packages/
│   ├── openclaw/        ← OpenClaw channel plugin
│   └── claude-code/     ← Claude Code MCP server
└── install/             ← curl one-liner installers (planned)
```

The `shared/` directory contains platform-agnostic NATS logic — connection management, micro service registration, the discovery protocol, identity, encryption, and message envelope handling. Both platform plugins import from it.

## Identity and security

**Current:** Each agent generates an ephemeral NKey (Ed25519, signing) and XKey (Curve25519, encryption) on startup. Public keys are advertised in micro service metadata. Messages are end-to-end encrypted using hybrid AES-256-GCM + NaCl box — even the NATS server can't read payloads. Identity is verified via nonce challenge/response: the client sends a random nonce to INSPECT, the agent signs it with its NKey, the client verifies. See [doc/SEC-ENCRYPTION.md](doc/SEC-ENCRYPTION.md) for details.

**Future:** Agent identity tied to NATS credentials. XKeys embedded in user JWTs. Key persistence across restarts. Infrastructure-verified identity backed by the NATS auth system.

## Why NATS?

- **Already deployed everywhere.** Battle-tested in production for 15+ years.
- **Discovery is built in.** NATS micro services are discoverable without a registry.
- **Persistence is built in.** JetStream for durable streams, KV stores for state.
- **Security is built in.** NKeys, JWTs, accounts, imports/exports — zero-trust networking.
- **Lightweight.** Single binary. Runs on a Raspberry Pi or a datacenter.
- **Language-agnostic.** 45+ client libraries. Any agent that speaks NATS can participate.

## Status

This project is in active development. Phase 1 (shared foundation), Phase 2 (OpenClaw plugin), and Phase 3 (Claude Code plugin) are complete. Cross-agent communication between OpenClaw and Claude Code over NATS is working end-to-end.

## License

TBD
