import type { ChannelPlugin } from "openclaw/plugin-sdk/core";
import { defineChannelPluginEntry } from "openclaw/plugin-sdk/core";
import { natsPlugin } from "./src/channel.js";
import { setNatsRuntime } from "./src/runtime.js";

export default defineChannelPluginEntry({
  id: "nats",
  name: "NATS",
  description: "NATS agent connectivity channel plugin",
  plugin: natsPlugin as ChannelPlugin,
  setRuntime: setNatsRuntime,
});

export { natsPlugin } from "./src/channel.js";
export { setNatsRuntime } from "./src/runtime.js";
