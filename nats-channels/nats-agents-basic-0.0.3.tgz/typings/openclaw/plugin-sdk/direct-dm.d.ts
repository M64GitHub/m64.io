/**
 * Minimal type stubs for openclaw/plugin-sdk/direct-dm.
 */

export declare function dispatchInboundDirectDmWithRuntime(params: {
  cfg: Record<string, unknown>;
  runtime: Record<string, unknown>;
  channel: string;
  channelLabel: string;
  accountId: string;
  peer: { kind: "direct"; id: string };
  senderId: string;
  senderAddress: string;
  recipientAddress: string;
  conversationLabel: string;
  rawBody: string;
  messageId: string;
  timestamp?: number;
  commandAuthorized?: boolean;
  bodyForAgent?: string;
  commandBody?: string;
  provider?: string;
  surface?: string;
  originatingChannel?: string;
  originatingTo?: string;
  extraContext?: Record<string, unknown>;
  deliver: (payload: { text?: string; mediaUrls?: string[]; mediaUrl?: string }, info?: { kind: string }) => Promise<void>;
  onRecordError: (err: unknown) => void;
  onDispatchError: (err: unknown, info: { kind: string }) => void;
}): Promise<unknown>;
