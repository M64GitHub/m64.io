import type { NatsConnection, Subscription } from "@nats-io/nats-core";
import { Svcm } from "@nats-io/services";
import type { ServiceHandler } from "@nats-io/services";
import type { AgentConfig, MessageHandler, StreamingMessageHandler, StreamResponder, RegisteredAgent } from "./types.js";
import {
  AGENT_TYPE,
  DEFAULT_VERSION,
  HEADER_STREAM,
  STREAM_ACCEPT,
  STREAM_STATUS_CHUNK,
  STREAM_STATUS_DONE,
  buildStreamChunkHeaders,
  buildInspectResponse,
  agentSubject,
  inspectSubject,
  parseEnvelope,
  toNatsHeaders,
  fromNatsHeaders,
} from "./protocol.js";

export async function registerAgent(
  nc: NatsConnection,
  config: AgentConfig,
  handler: MessageHandler | StreamingMessageHandler,
): Promise<RegisteredAgent> {
  const version = config.version ?? DEFAULT_VERSION;

  const svc = new Svcm(nc);
  const service = await svc.add({
    name: config.name,
    version,
    description: config.description,
    metadata: {
      type: AGENT_TYPE,
      platform: config.platform,
      description: config.description,
      ...config.metadata,
    },
  });

  const isStreamingHandler = handler.length >= 2;

  const inboxHandler: ServiceHandler = (err, msg) => {
    if (err) return;
    try {
      const hdrs = fromNatsHeaders(msg.headers);
      const callerWantsStream = isStreamingHandler && hdrs[HEADER_STREAM] === STREAM_ACCEPT;
      const envelope = parseEnvelope(msg.data);

      if (callerWantsStream && msg.reply) {
        // Streaming path: publish chunks to msg.reply, then send done
        let seq = 0;
        const streamResponder: StreamResponder = {
          isStreaming: true,
          sendChunk(text: string) {
            seq++;
            const chunkHdrs = buildStreamChunkHeaders(seq, STREAM_STATUS_CHUNK);
            nc.publish(msg.reply!, text, { headers: toNatsHeaders(chunkHdrs) });
          },
        };

        (handler as StreamingMessageHandler)(envelope, streamResponder).then(
          () => {
            seq++;
            const doneHdrs = buildStreamChunkHeaders(seq, STREAM_STATUS_DONE);
            nc.publish(msg.reply!, "", { headers: toNatsHeaders(doneHdrs) });
          },
          (error) => msg.respondError(500, (error as Error).message),
        );
      } else {
        // Single-shot path
        const invoke = isStreamingHandler
          ? (handler as StreamingMessageHandler)(envelope, { isStreaming: false, sendChunk() {} })
          : (handler as MessageHandler)(envelope);

        invoke.then(
          (response) => msg.respond(response),
          (error) => msg.respondError(500, (error as Error).message),
        );
      }
    } catch (e) {
      msg.respondError(400, (e as Error).message);
    }
  };

  service.addEndpoint("inbox", {
    subject: agentSubject(config.name, config.org),
    handler: inboxHandler,
  });

  const inspectSub: Subscription = nc.subscribe(inspectSubject(config.name, config.org), {
    callback: (_err, msg) => {
      const response = buildInspectResponse(config);
      msg.respond(JSON.stringify(response));
    },
  });

  console.error(
    `[agent] registered "${config.name}" (${config.platform}) — subject: ${agentSubject(config.name, config.org)}`,
  );

  return {
    service,
    stop: async () => {
      inspectSub.unsubscribe();
      await service.stop();
      console.error(`[agent] stopped "${config.name}"`);
    },
  };
}
