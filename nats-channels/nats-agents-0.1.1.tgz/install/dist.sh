#!/usr/bin/env bash
set -euo pipefail

VERSION=${1:?usage: dist.sh <version>  (e.g. dist.sh 0.1.0)}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname "$SCRIPT_DIR")"
cd "$REPO_DIR"

echo "=== Building nats-channel v${VERSION} ==="

# --- 1. Stamp version everywhere ---

# package.json (full)
sed -i "s/\"version\": \"[^\"]*\"/\"version\": \"${VERSION}\"/" package.json

# basic/package.json
sed -i "s/\"version\": \"[^\"]*\"/\"version\": \"${VERSION}\"/" basic/package.json

# shared/protocol.ts (full)
sed -i "s/DEFAULT_VERSION = \"[^\"]*\"/DEFAULT_VERSION = \"${VERSION}\"/" shared/protocol.ts

# basic/shared/protocol.ts
sed -i "s/DEFAULT_VERSION = \"[^\"]*\"/DEFAULT_VERSION = \"${VERSION}\"/" basic/shared/protocol.ts

# install/openclaw.sh
sed -i "s/PLUGIN_VERSION=\"[^\"]*\"/PLUGIN_VERSION=\"${VERSION}\"/" "$SCRIPT_DIR/openclaw.sh"

# install/openclaw-full.sh
sed -i "s/PLUGIN_VERSION=\"[^\"]*\"/PLUGIN_VERSION=\"${VERSION}\"/" "$SCRIPT_DIR/openclaw-full.sh"

echo "Stamped version ${VERSION} in all files"

# --- 2. Build basic package at ../nats-channel (SDK layout) ---

TARGET="../nats-channel"
# Preserve .git if it exists (separate repo)
if [[ -d "$TARGET/.git" ]]; then
  mv "$TARGET/.git" /tmp/_nats-channel-git-$$
fi
rm -rf "$TARGET"
mkdir -p "$TARGET"/{src/nats,typings/openclaw/plugin-sdk}
if [[ -d /tmp/_nats-channel-git-$$ ]]; then
  mv /tmp/_nats-channel-git-$$ "$TARGET/.git"
fi

# Top-level files
cp index.ts setup-entry.ts "$TARGET/"

# Overlay: basic-specific config + tsconfig
cp basic/package.json "$TARGET/"
cp basic/openclaw.plugin.json "$TARGET/"
cp basic/tsconfig.json "$TARGET/"
cp basic/README.md "$TARGET/"
cp basic/vitest.config.ts "$TARGET/"

# Typings (needed for TS compilation without real openclaw package)
cp typings/openclaw/plugin-sdk/*.d.ts "$TARGET/typings/openclaw/plugin-sdk/"

# src/ — basic overlay files + colocated test
cp basic/src/channel.ts "$TARGET/src/"
cp basic/src/gateway.ts "$TARGET/src/"
cp basic/src/accounts.ts "$TARGET/src/"
cp basic/src/runtime.ts "$TARGET/src/"
cp basic/src/types.ts "$TARGET/src/"
cp basic/src/channel.test.ts "$TARGET/src/"

# src/nats/ — shared protocol (was shared/)
cp shared/connection.ts "$TARGET/src/nats/"
cp basic/shared/index.ts "$TARGET/src/nats/"
cp basic/shared/protocol.ts "$TARGET/src/nats/"
cp basic/shared/micro.ts "$TARGET/src/nats/"
cp basic/shared/types.ts "$TARGET/src/nats/"

# Fix imports: ../shared/ → ./nats/ in src/*.ts files
sed -i 's|"../shared/|"./nats/|g' "$TARGET/src/"*.ts

echo "Built basic package at $TARGET"

# --- 3. Create basic tarball ---

BASIC_TAR="$SCRIPT_DIR/nats-agents-basic-${VERSION}.tgz"
tar czf "$BASIC_TAR" -C "$(dirname "$TARGET")" "$(basename "$TARGET")" \
    --transform="s|^$(basename "$TARGET")|.|"

echo "Created $BASIC_TAR"

# --- 4. Create full tarball ---

FULL_TAR="$SCRIPT_DIR/nats-agents-${VERSION}.tgz"
tar czf "$FULL_TAR" \
    --exclude='install/*.tgz' \
    --exclude='basic' \
    package.json tsconfig.json README.md index.ts setup-entry.ts \
    openclaw.plugin.json shared/ src/ typings/ install/ test/

echo "Created $FULL_TAR"

# --- Done ---

echo ""
echo "=== Done ==="
echo "  Basic:  $BASIC_TAR"
echo "  Full:   $FULL_TAR"
echo "  Output: $TARGET"
echo ""
echo "  Upload both .tgz + openclaw.sh + openclaw-full.sh to https://m64.io/nats-channels/"
