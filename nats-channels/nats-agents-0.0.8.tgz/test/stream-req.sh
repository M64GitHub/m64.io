#!/usr/bin/env bash
set -euo pipefail

# Stream a request to an agent and print chunks as they arrive.
# Usage: stream-req.sh [--org <org>] <agent-name> <message>
#
# Uses nats req --wait-for-empty to collect streaming chunks
# and exit on the empty done signal.

ORG=""
if [[ "${1:-}" == "--org" ]]; then
  ORG="${2:?--org requires a value}"
  shift 2
fi

AGENT=${1:?usage: stream-req.sh [--org <org>] <agent> <message>}
shift
MESSAGE="$*"
if [[ -z "$MESSAGE" ]]; then
  echo "usage: stream-req.sh [--org <org>] <agent> <message>"
  exit 1
fi

if [[ -n "$ORG" ]]; then
  SUBJECT="agents.oc.${ORG}.${AGENT}"
else
  SUBJECT="agents.oc.${AGENT}"
fi

exec nats req "$SUBJECT" \
  "{\"from\":\"cli\",\"body\":\"$MESSAGE\"}" \
  --wait-for-empty --timeout 60s --raw
