#!/usr/bin/env bash
set -euo pipefail

# Stream a request to an agent and print chunks as they arrive.
# Usage: stream-req.sh [--org <org>] <agent-name> <message>
#
# Unlike `nats req` (which waits for one response), this subscribes to a
# reply inbox and prints each chunk as it arrives until ctrl-c.

ORG=""
SERVER=""
while [[ "${1:-}" == --* ]]; do
  case "$1" in
    --org)    ORG="${2:?--org requires a value}"; shift 2 ;;
    --server) SERVER="${2:?--server requires a value}"; shift 2 ;;
    *) echo "unknown flag: $1"; exit 1 ;;
  esac
done

AGENT=${1:?usage: stream-req.sh [--org <org>] <agent> <message>}
shift
MESSAGE="$*"
if [[ -z "$MESSAGE" ]]; then
  echo "usage: stream-req.sh [--org <org>] <agent> <message>"
  exit 1
fi

INBOX="_INBOX.stream.$(openssl rand -hex 8)"
if [[ -n "$ORG" ]]; then
  SUBJECT="agents.oc.${ORG}.${AGENT}"
else
  SUBJECT="agents.oc.${AGENT}"
fi

echo "→ ${SUBJECT}"
echo "← subscribing to ${INBOX}"
echo ""

# Subscribe to reply inbox in background, print each chunk raw
nats sub "$INBOX" --raw ${SERVER:+--server "$SERVER"} &
SUB_PID=$!

# Give subscription time to register
sleep 0.3

# Publish request with reply-to and stream header
nats pub "$SUBJECT" \
  "{\"from\":\"cli\",\"body\":\"$MESSAGE\"}" \
  --reply "$INBOX" \
  --header "Nats-Agent-Stream:accepted" \
  ${SERVER:+--server "$SERVER"}

echo ""
echo "(waiting for chunks — ctrl-c to stop)"

# Wait for sub to end (it won't unless killed)
wait $SUB_PID 2>/dev/null || true
