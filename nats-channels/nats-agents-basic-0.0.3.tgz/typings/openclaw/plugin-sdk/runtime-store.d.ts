/**
 * Minimal type stubs for openclaw/plugin-sdk/compat.
 */

export declare function createPluginRuntimeStore<T>(errorMessage: string): {
  setRuntime: (next: T) => void;
  clearRuntime: () => void;
  tryGetRuntime: () => T | null;
  getRuntime: () => T;
};
