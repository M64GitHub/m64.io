import type { NatsConnection } from "@nats-io/nats-core";
import { Svcm } from "@nats-io/services";
import { randomUUID } from "crypto";
import type { AgentInfo, InspectResponse } from "./types.js";
import type { AgentIdentity } from "./identity.js";
import {
  encryptMessage, decryptMessage,
} from "./crypto.js";
import {
  AGENT_TYPE,
  buildEnvelope,
  agentSubject,
  inspectSubject,
  toNatsHeaders,
  fromNatsHeaders,
} from "./protocol.js";

const DEFAULT_DISCOVERY_TIMEOUT = 3000;
const DEFAULT_AGENT_TIMEOUT = 120_000;

export async function discoverAgents(
  nc: NatsConnection,
  timeout: number = DEFAULT_DISCOVERY_TIMEOUT,
): Promise<AgentInfo[]> {
  const svc = new Svcm(nc);
  const client = svc.client({ strategy: "stall", maxWait: timeout });
  const pings = await client.ping();

  const agents: AgentInfo[] = [];
  for await (const identity of pings) {
    if (identity.metadata?.type !== AGENT_TYPE) continue;
    agents.push({
      name: identity.name,
      id: identity.id,
      version: identity.version,
      description: identity.metadata.description ?? "",
      platform: identity.metadata.platform ?? "unknown",
      metadata: identity.metadata,
    });
  }

  return agents;
}

export async function getAgentInfo(
  nc: NatsConnection,
  name: string,
  opts?: {
    timeout?: number;
    identity?: AgentIdentity;
    org?: string;
  },
): Promise<InspectResponse> {
  const timeout = opts?.timeout ?? DEFAULT_DISCOVERY_TIMEOUT;
  const nonce = randomUUID();
  const msg = await nc.request(inspectSubject(name, opts?.org), nonce, { timeout });
  const info = JSON.parse(msg.string()) as InspectResponse;

  // Verify the agent signed our nonce (proves key ownership)
  if (opts?.identity) {
    info.verified = opts.identity.verify(nonce, info.identity.signature, info.identity.publicNKey);
  }

  return info;
}

/**
 * Collect a streaming response from `inbox` until an empty payload arrives.
 * Returns the accumulated text.
 */
async function collectStreamingResponse(
  inbox: { [Symbol.asyncIterator](): AsyncIterator<{ data: Uint8Array }>; unsubscribe(): void },
  timeout: number,
  onChunk?: (text: string) => void,
): Promise<string> {
  let accumulated = "";
  const timer = setTimeout(() => inbox.unsubscribe(), timeout);
  try {
    for await (const msg of inbox) {
      const text = new TextDecoder().decode(msg.data);
      if (text.length === 0) break; // empty payload = done
      accumulated += text;
      onChunk?.(text);
    }
  } finally {
    clearTimeout(timer);
  }
  return accumulated;
}

/**
 * Send a message to another agent and collect the streamed response.
 * Agents always stream: chunks published to reply subject, empty payload = done.
 */
export async function sendToAgent(
  nc: NatsConnection,
  senderName: string,
  targetName: string,
  message: string,
  opts?: {
    timeout?: number;
    identity?: AgentIdentity;
    encryption?: boolean;
    org?: string;
    onChunk?: (text: string) => void;
  },
): Promise<string> {
  const timeout = opts?.timeout ?? DEFAULT_AGENT_TIMEOUT;
  const identity = opts?.identity;
  const encryption = opts?.encryption === true;
  const org = opts?.org;
  const envelopeStr = buildEnvelope(senderName, message);

  // Create temp inbox to collect streaming response
  const inboxSubject = nc.options?.inboxPrefix
    ? `${nc.options.inboxPrefix}.${randomUUID().replace(/-/g, "")}`
    : `_INBOX.${randomUUID().replace(/-/g, "")}`;
  const inbox = nc.subscribe(inboxSubject);

  if (identity && encryption) {
    const info = await getAgentInfo(nc, targetName, { identity, org });
    const targetXKey = info.identity.publicXKey;

    const encrypted = encryptMessage(
      new TextEncoder().encode(envelopeStr),
      identity.xkey,
      targetXKey,
    );

    nc.publish(agentSubject(targetName, org), encrypted.payload, {
      reply: inboxSubject,
      headers: toNatsHeaders(encrypted.headers),
    });

    // For encrypted responses, collect and decrypt each chunk
    let accumulated = "";
    const timer = setTimeout(() => inbox.unsubscribe(), timeout);
    try {
      for await (const msg of inbox) {
        if (msg.data.length === 0) break;
        const hdrs = fromNatsHeaders((msg as Record<string, unknown>).headers as undefined);
        try {
          const decrypted = decryptMessage(msg.data, hdrs, identity.xkey);
          const text = new TextDecoder().decode(decrypted);
          accumulated += text;
          opts?.onChunk?.(text);
        } catch {
          // Plaintext fallback (agent may not encrypt response)
          const text = new TextDecoder().decode(msg.data);
          accumulated += text;
          opts?.onChunk?.(text);
        }
      }
    } finally {
      clearTimeout(timer);
    }
    return accumulated;
  }

  // Plaintext path
  nc.publish(agentSubject(targetName, org), envelopeStr, { reply: inboxSubject });
  return collectStreamingResponse(inbox, timeout, opts?.onChunk);
}

/**
 * Send a message to another agent and receive a streaming response with chunk callbacks.
 * Same as sendToAgent but with explicit onChunk support for backward compat.
 */
export async function sendToAgentStreaming(
  nc: NatsConnection,
  senderName: string,
  targetName: string,
  message: string,
  opts?: {
    timeout?: number;
    identity?: AgentIdentity;
    encryption?: boolean;
    org?: string;
    onChunk?: (text: string) => void;
  },
): Promise<string> {
  return sendToAgent(nc, senderName, targetName, message, opts);
}
