import { createUser, createCurve, fromPublic } from "@nats-io/nkeys";
import type { KeyPair } from "@nats-io/nkeys";

export type { KeyPair } from "@nats-io/nkeys";

export interface AgentIdentity {
  nkey: KeyPair;         // Ed25519 — signing / identity verification
  xkey: KeyPair;         // Curve25519 — encryption / decryption
  publicNKey: string;    // e.g. "UA..."
  publicXKey: string;    // e.g. "XA..."
  sign: (nonce: string) => string;
  verify: (nonce: string, sig: string, pubNKey: string) => boolean;
}

/**
 * Generate a fresh ephemeral identity for this agent session.
 * Keys are NOT persisted — a new identity is created on every startup.
 * TODO: Add optional key persistence for stable identity across restarts.
 */
export function generateIdentity(): AgentIdentity {
  const nkey = createUser();
  const xkey = createCurve();
  const encoder = new TextEncoder();

  return {
    nkey,
    xkey,
    publicNKey: nkey.getPublicKey(),
    publicXKey: xkey.getPublicKey(),
    sign: (nonce: string) =>
      Buffer.from(nkey.sign(encoder.encode(nonce))).toString("base64"),
    verify: (nonce: string, sig: string, pubNKey: string) => {
      try {
        const pub = fromPublic(pubNKey);
        return pub.verify(encoder.encode(nonce), Buffer.from(sig, "base64"));
      } catch {
        return false;
      }
    },
  };
}
