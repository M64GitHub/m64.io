import { connectToNats, drainConnection } from "../shared/connection.js";
import { registerAgent } from "../shared/micro.js";
import { discoverAgents, getAgentInfo, sendToAgent, sendToAgentStreaming } from "../shared/discovery.js";
import type { MessageEnvelope, StreamResponder } from "../shared/types.js";

let passed = 0;
let failed = 0;

function assert(condition: boolean, label: string) {
  if (condition) {
    console.log(`  \u2713 ${label}`);
    passed++;
  } else {
    console.log(`  \u2717 ${label}`);
    failed++;
  }
}

async function main() {
  console.log("\n--- NATS Agent Shared Library Test ---\n");

  // Connect
  const nc = await connectToNats();

  // Register a default agent (encryption off)
  const agent = await registerAgent(
    nc,
    {
      name: "test-agent",
      description: "A test agent for verification",
      platform: "test",
      metadata: { environment: "testing" },
    },
    async (envelope) => {
      return `echo: ${envelope.body}`;
    },
  );

  // Register an encrypted agent
  const encAgent = await registerAgent(
    nc,
    {
      name: "test-agent-enc",
      description: "An encrypted test agent",
      platform: "test",
      encryption: true,
    },
    async (envelope) => {
      return `echo: ${envelope.body}`;
    },
  );

  // Register a streaming agent
  const streamAgent = await registerAgent(
    nc,
    {
      name: "test-agent-stream",
      description: "A streaming test agent",
      platform: "test",
    },
    async (envelope: MessageEnvelope, stream: StreamResponder) => {
      const words = envelope.body.split(" ");
      for (const word of words) {
        stream.sendChunk(word + " ");
      }
      return `echo: ${envelope.body}`;
    },
  );

  // Register a streaming + encrypted agent
  const streamEncAgent = await registerAgent(
    nc,
    {
      name: "test-agent-stream-enc",
      description: "A streaming encrypted test agent",
      platform: "test",
      encryption: true,
    },
    async (envelope: MessageEnvelope, stream: StreamResponder) => {
      stream.sendChunk("part1 ");
      stream.sendChunk("part2 ");
      return `echo: ${envelope.body}`;
    },
  );

  // Brief delay for micro registration to propagate
  await new Promise((r) => setTimeout(r, 500));

  // Test 1: Discovery
  console.log("\n[Test] Discovery");
  const agents = await discoverAgents(nc);
  const found = agents.find((a) => a.name === "test-agent");
  assert(found !== undefined, "test-agent discovered");
  assert(found?.platform === "test", "platform metadata correct");
  assert(found?.metadata?.type === "agent", 'metadata.type is "agent"');
  assert(found?.metadata?.environment === "testing", "custom metadata preserved");
  assert(found?.metadata?.public_xkey?.startsWith("X") === true, "public XKey in metadata");

  // Test 2: INSPECT + nonce verification
  console.log("\n[Test] Inspect");
  const info = await getAgentInfo(nc, "test-agent", { identity: agent.identity });
  assert(info.name === "test-agent", "inspect returns correct name");
  assert(info.capabilities.length === 2, "two capabilities (prompt + notifications)");
  const promptCap = info.capabilities.find((c) => c.name === "prompt");
  assert(promptCap?.pattern === "request/reply", "prompt capability is request/reply");
  assert(promptCap?.endpoint === "agents.oc.test-agent", "prompt endpoint correct");
  assert(info.verified === true, "nonce signature verified (identity proven)");
  assert(info.identity.publicNKey.startsWith("U"), "real NKey present (U prefix)");
  assert(info.identity.publicXKey.startsWith("X"), "real XKey present (X prefix)");

  // Test 3: INSPECT encryption field
  console.log("\n[Test] Inspect encryption field");
  assert(info.encryption === false, "default agent: encryption is false");
  const encInfo = await getAgentInfo(nc, "test-agent-enc", { identity: encAgent.identity });
  assert(encInfo.encryption === true, "encrypted agent: encryption is true");

  // Test 4: Send message (plaintext — always streams, collected by sendToAgent)
  console.log("\n[Test] Messaging (plaintext)");
  const response = await sendToAgent(nc, "tester", "test-agent", "hello world");
  assert(response === "echo: hello world", "plaintext echo response matches");

  // Test 5: Send message with identity but encryption disabled (default)
  console.log("\n[Test] Messaging (identity present, encryption off)");
  const noEncResponse = await sendToAgent(nc, "tester", "test-agent", "no-encrypt test", {
    identity: agent.identity,
    encryption: false,
  });
  assert(noEncResponse === "echo: no-encrypt test", "identity present but plaintext when encryption off");

  // Test 6: Send message (encrypted)
  console.log("\n[Test] Messaging (encrypted)");
  const encResponse = await sendToAgent(nc, "tester", "test-agent-enc", "secret message", {
    identity: encAgent.identity,
    encryption: true,
  });
  assert(encResponse === "echo: secret message", "encrypted echo response matches");

  // Test 7: Streaming — plaintext (via sendToAgentStreaming with onChunk)
  console.log("\n[Test] Streaming (plaintext)");
  const chunks: string[] = [];
  const streamResponse = await sendToAgentStreaming(nc, "tester", "test-agent-stream", "hello world", {
    onChunk: (text) => {
      chunks.push(text);
    },
  });
  assert(streamResponse === "hello world ", "streaming accumulated response matches chunks");
  assert(chunks.length >= 2, `received ${chunks.length} chunks (expected >=2 for 'hello world')`);
  assert(chunks.some((c) => c.includes("hello")), "chunks contain 'hello'");

  // Test 8: Org namespace
  console.log("\n[Test] Org namespace");
  const orgAgent = await registerAgent(
    nc,
    {
      name: "test-agent-org",
      description: "An org-scoped agent",
      platform: "test",
      org: "testns",
    },
    async (envelope) => `echo: ${envelope.body}`,
  );
  await new Promise((r) => setTimeout(r, 300));

  const orgInfo = await getAgentInfo(nc, "test-agent-org", { org: "testns" });
  assert(orgInfo.name === "test-agent-org", "org agent: inspect works with org prefix");
  const orgPrompt = orgInfo.capabilities.find((c) => c.name === "prompt");
  assert(orgPrompt?.endpoint === "agents.oc.testns.test-agent-org", "org agent: endpoint includes org prefix");

  const orgResponse = await sendToAgent(nc, "tester", "test-agent-org", "org test", { org: "testns" });
  assert(orgResponse === "echo: org test", "org agent: messaging works with org prefix");

  await orgAgent.stop();

  // Cleanup
  await agent.stop();
  await encAgent.stop();
  await streamAgent.stop();
  await streamEncAgent.stop();
  await drainConnection(nc);

  // Summary
  console.log(`\n--- Results: ${passed} passed, ${failed} failed ---\n`);
  process.exit(failed > 0 ? 1 : 0);
}

main().catch((err) => {
  console.error("Test failed:", err);
  process.exit(1);
});
