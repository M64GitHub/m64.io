import { headers as createHeaders } from "@nats-io/nats-core";
import type { MsgHdrs } from "@nats-io/nats-core";
import type { AgentConfig, Capability, InspectResponse, MessageEnvelope } from "./types.js";
import type { AgentIdentity } from "./identity.js";

// --- Constants ---

export const AGENT_TYPE = "agent";
export const DEFAULT_VERSION = "1.0.0";

// --- Subject Builders ---

export function inboxSubject(name: string): string {
  return `agents.${name}.inbox`;
}

export function outboundSubject(name: string): string {
  return `agents.${name}.outbound`;
}

export function inspectSubject(name: string): string {
  return `agents.${name}.inspect`;
}

// --- INSPECT Response Builder ---

export function buildInspectResponse(
  config: AgentConfig,
  identity: AgentIdentity,
  nonce?: string,
): InspectResponse {
  const capabilities: Capability[] = [
    {
      name: "prompt",
      endpoint: inboxSubject(config.name),
      description: "Send a prompt and receive a response. Use natural language.",
      pattern: "request/reply",
    },
    {
      name: "notifications",
      endpoint: outboundSubject(config.name),
      description: "Subscribe to receive agent-initiated messages.",
      pattern: "pub/sub",
    },
  ];

  return {
    name: config.name,
    description: config.description,
    capabilities,
    encryption: config.encryption === true,
    identity: {
      publicNKey: identity.publicNKey,
      publicXKey: identity.publicXKey,
      signature: identity.sign(nonce ?? config.name),
    },
  };
}

// --- Envelope Utilities ---

export function buildEnvelope(from: string, body: string): string {
  return JSON.stringify({ from, body });
}

export function parseEnvelope(data: Uint8Array | string): MessageEnvelope {
  const text = typeof data === "string" ? data : new TextDecoder().decode(data);
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error("Invalid envelope: not valid JSON");
  }

  if (
    typeof parsed !== "object" ||
    parsed === null ||
    typeof (parsed as Record<string, unknown>).from !== "string" ||
    typeof (parsed as Record<string, unknown>).body !== "string"
  ) {
    throw new Error('Invalid envelope: must have "from" and "body" string fields');
  }

  return parsed as MessageEnvelope;
}

// --- NATS Header Helpers ---

export function toNatsHeaders(cryptoHeaders: Record<string, string>): MsgHdrs {
  const hdrs = createHeaders();
  for (const [key, value] of Object.entries(cryptoHeaders)) {
    hdrs.set(key, value);
  }
  return hdrs;
}

export function fromNatsHeaders(hdrs: MsgHdrs | undefined): Record<string, string> {
  const result: Record<string, string> = {};
  if (!hdrs) return result;
  for (const key of hdrs.keys()) {
    const values = hdrs.values(key);
    if (values && values.length > 0) {
      result[key] = values[0];
    }
  }
  return result;
}
