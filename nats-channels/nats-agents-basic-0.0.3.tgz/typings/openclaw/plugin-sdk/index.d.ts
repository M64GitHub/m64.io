/**
 * Minimal type stubs for openclaw/plugin-sdk.
 * Real types come from the OpenClaw runtime when the plugin is loaded.
 */

import type { TSchema } from "@sinclair/typebox";

export type { OpenClawConfig, PluginRuntime, ChannelPlugin } from "./core.js";

export interface ChannelGatewayContext<ResolvedAccount = unknown> {
  cfg: Record<string, unknown>;
  accountId: string;
  account: ResolvedAccount;
  runtime: Record<string, unknown>;
  abortSignal: AbortSignal;
  log?: {
    info?: (...args: unknown[]) => void;
    warn?: (...args: unknown[]) => void;
    error?: (...args: unknown[]) => void;
    debug?: (...args: unknown[]) => void;
  };
  getStatus: () => Record<string, unknown>;
  setStatus: (next: Record<string, unknown>) => void;
  channelRuntime?: Record<string, unknown>;
}

export interface ChannelAgentTool {
  name: string;
  label: string;
  description: string;
  parameters: TSchema;
  ownerOnly?: boolean;
  execute: (
    toolCallId: string,
    args: unknown,
  ) => Promise<{ content: Array<{ type: string; text: string }>; details?: unknown }>;
}
