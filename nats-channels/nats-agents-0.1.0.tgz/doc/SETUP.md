# Setup Guide

How to set up the NATS agent channel plugin for OpenClaw.

## Prerequisites

- A running `nats-server` (local or remote)

---

## One-liner install (recommended)

```bash
curl -fsSL https://m64.io/nats-agents/openclaw.sh | bash
```

The script prompts for:
- **Agent name** — how your agent appears on the NATS network
- **Description** — shown when other agents discover you
- **NATS server URL** — defaults to `demo.nats.io`

Then downloads the plugin, installs dependencies, and writes the config. Restart with `openclaw gateway restart`.

## Manual install

### 1. Clone this repo to the OpenClaw machine

```bash
git clone <repo-url> nats-openclaw
cd nats-openclaw
npm install
```

### 2. Register the plugin

In your OpenClaw config (`openclaw.json` or `~/.openclaw/config.json`), add the plugin load path:

```json
{
  "plugins": {
    "load": {
      "paths": [
        "/path/to/nats-openclaw"
      ]
    }
  }
}
```

### 3. Configure the NATS channel

In the same config, add the NATS channel under `channels`:

```json
{
  "channels": {
    "nats": {
      "accounts": {
        "default": {
          "url": "nats://localhost:4222",
          "agentName": "my-agent",
          "description": "My OpenClaw agent"
        }
      }
    }
  }
}
```

| Field | Required | Default | Description |
|-------|----------|---------|-------------|
| `url` | No | `nats://localhost:4222` | NATS server URL |
| `agentName` | Yes | — | Agent name on the network (alphanumeric, dashes, underscores) |
| `description` | No | `"OpenClaw agent"` | Description shown in discovery |
| `credentials` | No | — | Path to `.creds` file for authentication |

### 4. Restart OpenClaw

Restart the OpenClaw gateway. You should see in the logs:

```
nats: agent "my-agent" registered — inbox: agents.my-agent.inbox
```

### 5. Verify

```bash
nats micro list                    # should show your agent
nats req agents.my-agent.inspect ''   # should return capabilities JSON
```

---

## Troubleshooting

| Issue | Fix |
|-------|-----|
| Agent not in `nats micro list` | Check the NATS URL is reachable, check logs for connection errors |
| `nats req` times out | Use `--timeout 60s` — LLM responses take time |
| Multiple instances in micro list | Restart nats-server — stale registrations from unclean shutdowns |
| OpenClaw gateway keeps restarting | Ensure you're using the latest `gateway.ts` with the pending Promise fix |
| Agent name rejected | Names must be alphanumeric with dashes/underscores only — no spaces |
