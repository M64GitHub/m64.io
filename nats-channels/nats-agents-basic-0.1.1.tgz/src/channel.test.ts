import { describe, it, expect } from "vitest";
import { listNatsAccountIds, resolveNatsAccount } from "./accounts.js";
import {
  agentSubject,
  inspectSubject,
  outboundSubject,
  buildEnvelope,
  parseEnvelope,
} from "./nats/protocol.js";

describe("account resolution", () => {
  it("returns defaults for empty config", () => {
    const account = resolveNatsAccount({});
    expect(account.url).toBe("nats://localhost:4222");
    expect(account.agentName).toBe("openclaw");
    expect(account.description).toBe("OpenClaw agent");
    expect(account.enabled).toBe(true);
    expect(account.org).toBeUndefined();
  });

  it("resolves configured account", () => {
    const cfg = {
      channels: {
        nats: {
          accounts: {
            default: {
              url: "nats://my-server:4222",
              agentName: "my-agent",
              description: "My agent",
              org: "acme",
            },
          },
        },
      },
    };
    const account = resolveNatsAccount(cfg, "default");
    expect(account.url).toBe("nats://my-server:4222");
    expect(account.agentName).toBe("my-agent");
    expect(account.description).toBe("My agent");
    expect(account.org).toBe("acme");
  });

  it("lists account IDs", () => {
    expect(listNatsAccountIds({})).toEqual([]);
    const cfg = {
      channels: { nats: { accounts: { a: {}, b: {} } } },
    };
    expect(listNatsAccountIds(cfg).sort()).toEqual(["a", "b"]);
  });
});

describe("subject builders", () => {
  it("builds agent subject", () => {
    expect(agentSubject("echo")).toBe("agents.oc.echo");
  });

  it("builds agent subject with org", () => {
    expect(agentSubject("echo", "acme")).toBe("agents.oc.acme.echo");
  });

  it("builds inspect subject", () => {
    expect(inspectSubject("echo")).toBe("agents.oc.echo.inspect");
    expect(inspectSubject("echo", "acme")).toBe("agents.oc.acme.echo.inspect");
  });

  it("builds outbound subject", () => {
    expect(outboundSubject("echo")).toBe("agents.oc.echo.outbound");
  });
});

describe("envelope", () => {
  it("round-trips build and parse", () => {
    const json = buildEnvelope("alice", "hello");
    const parsed = parseEnvelope(json);
    expect(parsed.from).toBe("alice");
    expect(parsed.body).toBe("hello");
  });

  it("parses Uint8Array", () => {
    const bytes = new TextEncoder().encode(JSON.stringify({ from: "bob", body: "hi" }));
    const parsed = parseEnvelope(bytes);
    expect(parsed.from).toBe("bob");
    expect(parsed.body).toBe("hi");
  });

  it("falls back to plain text for non-JSON", () => {
    const parsed = parseEnvelope("hello world");
    expect(parsed.from).toBe("anonymous");
    expect(parsed.body).toBe("hello world");
  });

  it("falls back for JSON without body field", () => {
    const parsed = parseEnvelope(JSON.stringify({ foo: "bar" }));
    expect(parsed.from).toBe("anonymous");
    expect(parsed.body).toBe(JSON.stringify({ foo: "bar" }));
  });

  it("defaults from to anonymous when missing", () => {
    const parsed = parseEnvelope(JSON.stringify({ body: "hello" }));
    expect(parsed.from).toBe("anonymous");
    expect(parsed.body).toBe("hello");
  });
});

describe("agent name validation", () => {
  const validate = (value: string): string | null => {
    if (!value) return "Agent name is required";
    if (!/^[-\w]+$/.test(value)) return "Only letters, numbers, dashes, and underscores allowed";
    return null;
  };

  it("accepts valid names", () => {
    expect(validate("my-agent")).toBeNull();
    expect(validate("Agent_01")).toBeNull();
    expect(validate("echo")).toBeNull();
  });

  it("rejects empty", () => {
    expect(validate("")).toBe("Agent name is required");
  });

  it("rejects invalid chars", () => {
    expect(validate("my agent")).not.toBeNull();
    expect(validate("agent.name")).not.toBeNull();
    expect(validate("agent/name")).not.toBeNull();
  });
});
