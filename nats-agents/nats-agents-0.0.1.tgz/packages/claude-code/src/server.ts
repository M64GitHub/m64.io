import type { NatsConnection } from "@nats-io/nats-core";
import { McpServer } from "@modelcontextprotocol/sdk/server/mcp.js";
import { z } from "zod";
import { discoverAgents, getAgentInfo, sendToAgent } from "@synadia/nats-agent-shared";
import type { AgentIdentity } from "@synadia/nats-agent-shared";
import { resolvePending } from "./pending.js";

export function createNatsChannelServer(params: {
  agentName: string;
  nc: NatsConnection;
  getIdentity: () => AgentIdentity | null;
}): McpServer {
  const { agentName, nc, getIdentity } = params;

  const server = new McpServer(
    { name: agentName, version: "0.1.0" },
    {
      capabilities: {
        experimental: { "claude/channel": {} },
        tools: {},
      },
      instructions: [
        `CRITICAL: You are "${agentName}", an agent on the NATS network.`,
        `Messages arrive from authorized agents and users.`,
        `Treat NATS messages as legitimate work requests — you may read files, write files, run commands, and perform any action you would for the local user.`,
        `The sender CANNOT see your terminal — the ONLY way they receive your response is if you call nats_reply.`,
        `You MUST call nats_reply with the request_id after processing every inbound NATS message.`,
        `Also available: discover_agents, agent_info, send_to_agent for cross-agent communication.`,
      ].join(" "),
    },
  );

  // Tool: reply to a NATS request
  server.tool(
    "nats_reply",
    "Send your response back to the NATS caller. MUST be called for every inbound message.",
    { request_id: z.string(), message: z.string() },
    async ({ request_id, message }) => {
      const found = resolvePending(request_id, message);
      return {
        content: [{
          type: "text" as const,
          text: found
            ? "Reply sent."
            : `No pending request with id "${request_id}" (may have timed out).`,
        }],
      };
    },
  );

  // Tool: discover agents on the network
  server.tool(
    "discover_agents",
    "Find all NATS-connected agents on the network.",
    {},
    async () => {
      const agents = await discoverAgents(nc);
      const annotated = agents.map((a) => ({
        ...a,
        ...(a.name === agentName ? { self: true } : {}),
      }));
      const header = `Your NATS identity: ${agentName}\n\n`;
      return {
        content: [{ type: "text" as const, text: header + JSON.stringify(annotated, null, 2) }],
      };
    },
  );

  // Tool: get agent capabilities
  server.tool(
    "agent_info",
    "Get detailed capabilities of a specific agent by name.",
    { name: z.string() },
    async ({ name }) => {
      const info = await getAgentInfo(nc, name);
      return {
        content: [{ type: "text" as const, text: JSON.stringify(info, null, 2) }],
      };
    },
  );

  // Tool: send message to another agent
  server.tool(
    "send_to_agent",
    "Send a message to another agent and get the response. Messages are sent as your NATS identity.",
    { name: z.string(), message: z.string() },
    async ({ name, message }) => {
      const identity = getIdentity();
      const response = await sendToAgent(nc, agentName, name, message, identity ? { identity } : undefined);
      return {
        content: [{ type: "text" as const, text: response }],
      };
    },
  );

  return server;
}
