import type { NatsConnection, Subscription } from "@nats-io/nats-core";
import { Svcm } from "@nats-io/services";
import type { ServiceHandler } from "@nats-io/services";
import type { AgentConfig, MessageHandler, StreamingMessageHandler, StreamResponder, RegisteredAgent } from "./types.js";
import { generateIdentity } from "./identity.js";
import type { AgentIdentity } from "./identity.js";
import {
  encryptMessage, decryptMessage, decryptMessageRetainingSession,
  encryptChunk, HEADER_SENDER_XKEY,
  type SessionKeyMaterial,
} from "./crypto.js";
import {
  AGENT_TYPE,
  DEFAULT_VERSION,
  HEADER_STREAM,
  HEADER_STREAM_STATUS,
  HEADER_CRYPTO_MODE,
  STREAM_ACCEPT,
  STREAM_STATUS_CHUNK,
  STREAM_STATUS_DONE,
  CRYPTO_MODE_STREAM,
  buildStreamChunkHeaders,
  buildInspectResponse,
  agentSubject,
  inspectSubject,
  parseEnvelope,
  toNatsHeaders,
  fromNatsHeaders,
} from "./protocol.js";

export async function registerAgent(
  nc: NatsConnection,
  config: AgentConfig,
  handler: MessageHandler | StreamingMessageHandler,
): Promise<RegisteredAgent> {
  const identity = generateIdentity();
  const version = config.version ?? DEFAULT_VERSION;

  const svc = new Svcm(nc);
  const service = await svc.add({
    name: config.name,
    version,
    description: config.description,
    metadata: {
      type: AGENT_TYPE,
      platform: config.platform,
      description: config.description,
      public_nkey: identity.publicNKey,
      public_xkey: identity.publicXKey,
      ...config.metadata,
    },
  });

  const encryptionEnabled = config.encryption === true;
  const streamingEnabled = config.streaming === true;
  const isStreamingHandler = handler.length >= 2;

  const inboxHandler: ServiceHandler = (err, msg) => {
    if (err) return;
    try {
      const hdrs = fromNatsHeaders(msg.headers);
      const isEncrypted = encryptionEnabled && Boolean(hdrs[HEADER_SENDER_XKEY]);
      const callerWantsStream = streamingEnabled && isStreamingHandler && hdrs[HEADER_STREAM] === STREAM_ACCEPT;

      let envelopeData: Uint8Array | string;
      let senderXKey: string | undefined;
      let session: SessionKeyMaterial | undefined;

      if (isEncrypted) {
        if (callerWantsStream) {
          const result = decryptMessageRetainingSession(msg.data, hdrs, identity.xkey);
          envelopeData = result.plaintext;
          session = result.session;
        } else {
          envelopeData = decryptMessage(msg.data, hdrs, identity.xkey);
        }
        senderXKey = hdrs[HEADER_SENDER_XKEY];
      } else {
        envelopeData = msg.data;
      }

      const envelope = parseEnvelope(envelopeData);

      if (callerWantsStream && msg.reply) {
        // Streaming path: publish chunks to msg.reply, then send done
        let seq = 0;
        const streamResponder: StreamResponder = {
          isStreaming: true,
          sendChunk(text: string) {
            seq++;
            const chunkHdrs = buildStreamChunkHeaders(seq, STREAM_STATUS_CHUNK);
            if (isEncrypted && session) {
              const encrypted = encryptChunk(session, seq, new TextEncoder().encode(text));
              chunkHdrs[HEADER_CRYPTO_MODE] = CRYPTO_MODE_STREAM;
              nc.publish(msg.reply!, encrypted, { headers: toNatsHeaders(chunkHdrs) });
            } else {
              nc.publish(msg.reply!, text, { headers: toNatsHeaders(chunkHdrs) });
            }
          },
        };

        (handler as StreamingMessageHandler)(envelope, streamResponder).then(
          () => {
            // Send empty done signal — all content was delivered via sendChunk()
            seq++;
            const doneHdrs = buildStreamChunkHeaders(seq, STREAM_STATUS_DONE);
            nc.publish(msg.reply!, "", { headers: toNatsHeaders(doneHdrs) });
          },
          (error) => msg.respondError(500, (error as Error).message),
        );
      } else {
        // Single-shot path
        const invoke = isStreamingHandler
          ? (handler as StreamingMessageHandler)(envelope, { isStreaming: false, sendChunk() {} })
          : (handler as MessageHandler)(envelope);

        invoke.then(
          (response) => {
            if (isEncrypted && senderXKey) {
              const encrypted = encryptMessage(
                new TextEncoder().encode(response),
                identity.xkey,
                senderXKey,
              );
              msg.respond(encrypted.payload, { headers: toNatsHeaders(encrypted.headers) });
            } else {
              msg.respond(response);
            }
          },
          (error) => msg.respondError(500, (error as Error).message),
        );
      }
    } catch (e) {
      msg.respondError(400, (e as Error).message);
    }
  };

  service.addEndpoint("inbox", {
    subject: agentSubject(config.name, config.org),
    handler: inboxHandler,
  });

  const inspectSub: Subscription = nc.subscribe(inspectSubject(config.name, config.org), {
    callback: (_err, msg) => {
      const nonce = msg.data.length > 0 ? new TextDecoder().decode(msg.data) : undefined;
      const response = buildInspectResponse(config, identity, nonce);
      msg.respond(JSON.stringify(response));
    },
  });

  console.error(
    `[agent] registered "${config.name}" (${config.platform}) — subject: ${agentSubject(config.name, config.org)}`,
  );

  return {
    service,
    identity,
    stop: async () => {
      inspectSub.unsubscribe();
      await service.stop();
      console.error(`[agent] stopped "${config.name}"`);
    },
  };
}
