const DEFAULT_TIMEOUT_MS = 120_000;

type PendingRequest = {
  resolve: (response: string) => void;
  timer: ReturnType<typeof setTimeout>;
};

const pending = new Map<string, PendingRequest>();

let counter = 0;

export function generateRequestId(): string {
  return `req-${Date.now()}-${++counter}`;
}

export function addPending(
  id: string,
  resolve: (response: string) => void,
  timeoutMs: number = DEFAULT_TIMEOUT_MS,
): void {
  const timer = setTimeout(() => {
    const entry = pending.get(id);
    if (entry) {
      pending.delete(id);
      entry.resolve("[timeout] Claude Code did not reply within the time limit.");
    }
  }, timeoutMs);
  pending.set(id, { resolve, timer });
}

export function resolvePending(id: string, response: string): boolean {
  const entry = pending.get(id);
  if (!entry) return false;
  clearTimeout(entry.timer);
  pending.delete(id);
  entry.resolve(response);
  return true;
}

export function removePending(id: string): void {
  const entry = pending.get(id);
  if (entry) {
    clearTimeout(entry.timer);
    pending.delete(id);
  }
}
