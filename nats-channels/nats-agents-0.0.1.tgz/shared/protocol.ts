import { headers as createHeaders } from "@nats-io/nats-core";
import type { MsgHdrs } from "@nats-io/nats-core";
import type { AgentConfig, Capability, InspectResponse, MessageEnvelope } from "./types.js";
import type { AgentIdentity } from "./identity.js";

// --- Constants ---

export const AGENT_TYPE = "agent";
export const DEFAULT_VERSION = "0.0.1";

// --- Streaming Headers ---

export const HEADER_STREAM = "Nats-Agent-Stream";
export const HEADER_STREAM_STATUS = "Nats-Agent-Stream-Status";
export const HEADER_STREAM_SEQ = "Nats-Agent-Stream-Seq";
export const HEADER_STREAM_KIND = "Nats-Agent-Stream-Kind";
export const HEADER_CRYPTO_MODE = "Nats-Agent-Crypto-Mode";

export const STREAM_ACCEPT = "accepted";
export const STREAM_STATUS_CHUNK = "chunk";
export const STREAM_STATUS_DONE = "done";
export const CRYPTO_MODE_STREAM = "stream";

export function buildStreamChunkHeaders(
  seq: number,
  status: "chunk" | "done",
  kind?: string,
): Record<string, string> {
  const hdrs: Record<string, string> = {
    [HEADER_STREAM_STATUS]: status,
    [HEADER_STREAM_SEQ]: String(seq),
  };
  if (kind) hdrs[HEADER_STREAM_KIND] = kind;
  return hdrs;
}

// --- Subject Builders ---

export function agentSubject(name: string, org?: string): string {
  return org ? `agents.oc.${org}.${name}` : `agents.oc.${name}`;
}

export function inspectSubject(name: string, org?: string): string {
  return `${agentSubject(name, org)}.inspect`;
}

export function outboundSubject(name: string, org?: string): string {
  return `${agentSubject(name, org)}.outbound`;
}

/** @deprecated Use agentSubject() — kept for backward compat */
export const inboxSubject = agentSubject;

// --- INSPECT Response Builder ---

export function buildInspectResponse(
  config: AgentConfig,
  identity: AgentIdentity,
  nonce?: string,
): InspectResponse {
  const capabilities: Capability[] = [
    {
      name: "prompt",
      endpoint: agentSubject(config.name, config.org),
      description: "Send a prompt and receive a response. Use natural language.",
      pattern: "request/reply",
      streaming: true,
    },
    {
      name: "notifications",
      endpoint: outboundSubject(config.name, config.org),
      description: "Subscribe to receive agent-initiated messages.",
      pattern: "pub/sub",
    },
  ];

  return {
    name: config.name,
    description: config.description,
    capabilities,
    encryption: config.encryption === true,
    identity: {
      publicNKey: identity.publicNKey,
      publicXKey: identity.publicXKey,
      signature: identity.sign(nonce ?? config.name),
    },
  };
}

// --- Envelope Utilities ---

export function buildEnvelope(from: string, body: string): string {
  return JSON.stringify({ from, body });
}

export function parseEnvelope(data: Uint8Array | string): MessageEnvelope {
  const text = typeof data === "string" ? data : new TextDecoder().decode(data);
  let parsed: unknown;
  try {
    parsed = JSON.parse(text);
  } catch {
    throw new Error("Invalid envelope: not valid JSON");
  }

  if (
    typeof parsed !== "object" ||
    parsed === null ||
    typeof (parsed as Record<string, unknown>).from !== "string" ||
    typeof (parsed as Record<string, unknown>).body !== "string"
  ) {
    throw new Error('Invalid envelope: must have "from" and "body" string fields');
  }

  return parsed as MessageEnvelope;
}

// --- NATS Header Helpers ---

export function toNatsHeaders(cryptoHeaders: Record<string, string>): MsgHdrs {
  const hdrs = createHeaders();
  for (const [key, value] of Object.entries(cryptoHeaders)) {
    hdrs.set(key, value);
  }
  return hdrs;
}

export function fromNatsHeaders(hdrs: MsgHdrs | undefined): Record<string, string> {
  const result: Record<string, string> = {};
  if (!hdrs) return result;
  for (const key of hdrs.keys()) {
    const values = hdrs.values(key);
    if (values && values.length > 0) {
      result[key] = values[0];
    }
  }
  return result;
}
