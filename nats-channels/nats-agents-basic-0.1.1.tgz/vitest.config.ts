import { defineConfig } from "vitest/config";
import { resolve } from "path";

export default defineConfig({
  resolve: {
    alias: {
      "openclaw/plugin-sdk/core": resolve(__dirname, "typings/openclaw/plugin-sdk/core.d.ts"),
      "openclaw/plugin-sdk/runtime-store": resolve(__dirname, "typings/openclaw/plugin-sdk/runtime-store.d.ts"),
      "openclaw/plugin-sdk/direct-dm": resolve(__dirname, "typings/openclaw/plugin-sdk/direct-dm.d.ts"),
      "openclaw/plugin-sdk": resolve(__dirname, "typings/openclaw/plugin-sdk/index.d.ts"),
    },
  },
});
