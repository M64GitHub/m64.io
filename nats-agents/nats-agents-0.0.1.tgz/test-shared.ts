import { connectToNats, drainConnection } from "./shared/connection.js";
import { registerAgent } from "./shared/micro.js";
import { discoverAgents, getAgentInfo, sendToAgent } from "./shared/discovery.js";

let passed = 0;
let failed = 0;

function assert(condition: boolean, label: string) {
  if (condition) {
    console.log(`  \u2713 ${label}`);
    passed++;
  } else {
    console.log(`  \u2717 ${label}`);
    failed++;
  }
}

async function main() {
  console.log("\n--- NATS Agent Shared Library Test ---\n");

  // Connect
  const nc = await connectToNats();

  // Register a mock agent that echoes messages
  const agent = await registerAgent(
    nc,
    {
      name: "test-agent",
      description: "A test agent for verification",
      platform: "test",
      metadata: { environment: "testing" },
    },
    async (envelope) => {
      return `echo: ${envelope.body}`;
    },
  );

  // Brief delay for micro registration to propagate
  await new Promise((r) => setTimeout(r, 500));

  // Test 1: Discovery
  console.log("\n[Test] Discovery");
  const agents = await discoverAgents(nc);
  const found = agents.find((a) => a.name === "test-agent");
  assert(found !== undefined, "test-agent discovered");
  assert(found?.platform === "test", "platform metadata correct");
  assert(found?.metadata?.type === "agent", 'metadata.type is "agent"');
  assert(found?.metadata?.environment === "testing", "custom metadata preserved");
  assert(found?.metadata?.public_xkey?.startsWith("X") === true, "public XKey in metadata");

  // Test 2: INSPECT + nonce verification
  console.log("\n[Test] Inspect");
  const info = await getAgentInfo(nc, "test-agent", { identity: agent.identity });
  assert(info.name === "test-agent", "inspect returns correct name");
  assert(info.capabilities.length === 2, "two capabilities (prompt + notifications)");
  const promptCap = info.capabilities.find((c) => c.name === "prompt");
  assert(promptCap?.pattern === "request/reply", "prompt capability is request/reply");
  assert(promptCap?.endpoint === "agents.test-agent.inbox", "prompt endpoint correct");
  assert(info.verified === true, "nonce signature verified (identity proven)");
  assert(info.identity.publicNKey.startsWith("U"), "real NKey present (U prefix)");
  assert(info.identity.publicXKey.startsWith("X"), "real XKey present (X prefix)");

  // Test 3: Send message (plaintext — no identity passed)
  console.log("\n[Test] Messaging (plaintext)");
  const response = await sendToAgent(nc, "tester", "test-agent", "hello world");
  assert(response === "echo: hello world", "plaintext echo response matches");

  // Test 4: Send message (encrypted — identity passed)
  console.log("\n[Test] Messaging (encrypted)");
  const encResponse = await sendToAgent(nc, "tester", "test-agent", "secret message", {
    identity: agent.identity,
  });
  assert(encResponse === "echo: secret message", "encrypted echo response matches");

  // Cleanup
  await agent.stop();
  await drainConnection(nc);

  // Summary
  console.log(`\n--- Results: ${passed} passed, ${failed} failed ---\n`);
  process.exit(failed > 0 ? 1 : 0);
}

main().catch((err) => {
  console.error("Test failed:", err);
  process.exit(1);
});
