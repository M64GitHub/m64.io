import type { NatsConnection, Subscription } from "@nats-io/nats-core";
import { Svcm } from "@nats-io/services";
import type { ServiceHandler } from "@nats-io/services";
import type { AgentConfig, MessageHandler, StreamingMessageHandler, StreamResponder, RegisteredAgent } from "./types.js";
import {
  AGENT_TYPE,
  DEFAULT_VERSION,
  buildInspectResponse,
  agentSubject,
  inspectSubject,
  parseEnvelope,
} from "./protocol.js";

export async function registerAgent(
  nc: NatsConnection,
  config: AgentConfig,
  handler: MessageHandler | StreamingMessageHandler,
): Promise<RegisteredAgent> {
  const version = config.version ?? DEFAULT_VERSION;

  const svc = new Svcm(nc);
  const service = await svc.add({
    name: config.name,
    version,
    description: config.description,
    metadata: {
      type: AGENT_TYPE,
      platform: config.platform,
      description: config.description,
      ...config.metadata,
    },
  });

  const isStreamingHandler = handler.length >= 2;

  const inboxHandler: ServiceHandler = (err, msg) => {
    if (err || !msg.reply) return;
    try {
      const envelope = parseEnvelope(msg.data);

      if (isStreamingHandler) {
        // Streaming handler: publish each chunk, then empty done signal
        const streamResponder: StreamResponder = {
          sendChunk(text: string) {
            nc.publish(msg.reply!, text);
          },
        };

        (handler as StreamingMessageHandler)(envelope, streamResponder).then(
          () => {
            nc.publish(msg.reply!, "");
          },
          (error) => msg.respondError(500, (error as Error).message),
        );
      } else {
        // Plain handler: publish response, then empty done signal
        (handler as MessageHandler)(envelope).then(
          (response) => {
            nc.publish(msg.reply!, response);
            nc.publish(msg.reply!, "");
          },
          (error) => msg.respondError(500, (error as Error).message),
        );
      }
    } catch (e) {
      msg.respondError(400, (e as Error).message);
    }
  };

  service.addEndpoint("inbox", {
    subject: agentSubject(config.name, config.org),
    handler: inboxHandler,
  });

  const inspectSub: Subscription = nc.subscribe(inspectSubject(config.name, config.org), {
    callback: (_err, msg) => {
      const response = buildInspectResponse(config);
      msg.respond(JSON.stringify(response));
    },
  });

  console.error(
    `[agent] registered "${config.name}" (${config.platform}) — subject: ${agentSubject(config.name, config.org)}`,
  );

  return {
    service,
    stop: async () => {
      inspectSub.unsubscribe();
      await service.stop();
      console.error(`[agent] stopped "${config.name}"`);
    },
  };
}
