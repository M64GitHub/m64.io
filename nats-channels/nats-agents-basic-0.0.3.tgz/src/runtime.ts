import type { NatsConnection } from "@nats-io/nats-core";
import type { PluginRuntime } from "openclaw/plugin-sdk/core";
import { createPluginRuntimeStore } from "openclaw/plugin-sdk/runtime-store";

export type NatsRuntime = PluginRuntime;

export const {
  setRuntime: setNatsRuntime,
  clearRuntime: clearNatsRuntime,
  getRuntime: getNatsRuntime,
} = createPluginRuntimeStore<NatsRuntime>("NATS runtime not initialized");

// Active connection state — set by gateway, read by outbound
let activeNc: NatsConnection | null = null;
let activeAgentName: string | null = null;
let activeOrg: string | undefined;

export function setActiveConnection(
  nc: NatsConnection | null,
  agentName: string | null,
  org?: string,
): void {
  activeNc = nc;
  activeAgentName = agentName;
  activeOrg = org;
}

export function getActiveConnection(): NatsConnection | null {
  return activeNc;
}

export function getActiveAgentName(): string | null {
  return activeAgentName;
}

export function getActiveOrg(): string | undefined {
  return activeOrg;
}
