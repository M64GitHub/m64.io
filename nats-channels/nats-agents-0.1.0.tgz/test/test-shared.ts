import { connectToNats, drainConnection } from "../shared/connection.js";
import { registerAgent } from "../shared/micro.js";
import { discoverAgents, getAgentInfo, sendToAgent } from "../shared/discovery.js";

let passed = 0;
let failed = 0;

function assert(condition: boolean, label: string) {
  if (condition) {
    console.log(`  \u2713 ${label}`);
    passed++;
  } else {
    console.log(`  \u2717 ${label}`);
    failed++;
  }
}

async function main() {
  console.log("\n--- NATS Agent Shared Library Test ---\n");

  // Connect
  const nc = await connectToNats();

  // Register a default agent (encryption off by default)
  const agent = await registerAgent(
    nc,
    {
      name: "test-agent",
      description: "A test agent for verification",
      platform: "test",
      metadata: { environment: "testing" },
    },
    async (envelope) => {
      return `echo: ${envelope.body}`;
    },
  );

  // Register an encrypted agent
  const encAgent = await registerAgent(
    nc,
    {
      name: "test-agent-enc",
      description: "An encrypted test agent",
      platform: "test",
      encryption: true,
    },
    async (envelope) => {
      return `echo: ${envelope.body}`;
    },
  );

  // Brief delay for micro registration to propagate
  await new Promise((r) => setTimeout(r, 500));

  // Test 1: Discovery
  console.log("\n[Test] Discovery");
  const agents = await discoverAgents(nc);
  const found = agents.find((a) => a.name === "test-agent");
  assert(found !== undefined, "test-agent discovered");
  assert(found?.platform === "test", "platform metadata correct");
  assert(found?.metadata?.type === "agent", 'metadata.type is "agent"');
  assert(found?.metadata?.environment === "testing", "custom metadata preserved");
  assert(found?.metadata?.public_xkey?.startsWith("X") === true, "public XKey in metadata");

  // Test 2: INSPECT + nonce verification
  console.log("\n[Test] Inspect");
  const info = await getAgentInfo(nc, "test-agent", { identity: agent.identity });
  assert(info.name === "test-agent", "inspect returns correct name");
  assert(info.capabilities.length === 2, "two capabilities (prompt + notifications)");
  const promptCap = info.capabilities.find((c) => c.name === "prompt");
  assert(promptCap?.pattern === "request/reply", "prompt capability is request/reply");
  assert(promptCap?.endpoint === "agents.test-agent.inbox", "prompt endpoint correct");
  assert(info.verified === true, "nonce signature verified (identity proven)");
  assert(info.identity.publicNKey.startsWith("U"), "real NKey present (U prefix)");
  assert(info.identity.publicXKey.startsWith("X"), "real XKey present (X prefix)");

  // Test 3: INSPECT encryption field — default agent
  console.log("\n[Test] Inspect encryption field");
  assert(info.encryption === false, "default agent: encryption is false");
  const encInfo = await getAgentInfo(nc, "test-agent-enc", { identity: encAgent.identity });
  assert(encInfo.encryption === true, "encrypted agent: encryption is true");

  // Test 4: Send message (plaintext — no identity)
  console.log("\n[Test] Messaging (plaintext)");
  const response = await sendToAgent(nc, "tester", "test-agent", "hello world");
  assert(response === "echo: hello world", "plaintext echo response matches");

  // Test 5: Send message with identity but encryption disabled (default)
  console.log("\n[Test] Messaging (identity present, encryption off)");
  const noEncResponse = await sendToAgent(nc, "tester", "test-agent", "no-encrypt test", {
    identity: agent.identity,
    encryption: false,
  });
  assert(noEncResponse === "echo: no-encrypt test", "identity present but plaintext when encryption off");

  // Test 6: Send message (encrypted — identity + encryption: true)
  console.log("\n[Test] Messaging (encrypted)");
  const encResponse = await sendToAgent(nc, "tester", "test-agent-enc", "secret message", {
    identity: encAgent.identity,
    encryption: true,
  });
  assert(encResponse === "echo: secret message", "encrypted echo response matches");

  // Cleanup
  await agent.stop();
  await encAgent.stop();
  await drainConnection(nc);

  // Summary
  console.log(`\n--- Results: ${passed} passed, ${failed} failed ---\n`);
  process.exit(failed > 0 ? 1 : 0);
}

main().catch((err) => {
  console.error("Test failed:", err);
  process.exit(1);
});
