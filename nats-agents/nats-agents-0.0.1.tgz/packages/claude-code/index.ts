import { execSync } from "node:child_process";
import { basename } from "node:path";
import { StdioServerTransport } from "@modelcontextprotocol/sdk/server/stdio.js";
import { connectToNats, drainConnection } from "@synadia/nats-agent-shared";
import { createNatsChannelServer } from "./src/server.js";
import { startNatsBridge } from "./src/nats-bridge.js";

// --- stdout is reserved for MCP protocol ---
const log = (...args: unknown[]) => console.error("[nats-cc]", ...args);

// --- Config from environment ---
function autoDetectName(): string {
  try {
    const remote = execSync("git remote get-url origin", { encoding: "utf-8" }).trim();
    const match = remote.match(/\/([^/]+?)(?:\.git)?$/);
    if (match) return match[1];
  } catch {}
  return basename(process.cwd());
}

function autoDetectMetadata(): Record<string, string> {
  const meta: Record<string, string> = {
    path: process.cwd(),
  };
  try {
    const remote = execSync("git remote get-url origin", { encoding: "utf-8" }).trim();
    meta.repo = remote;
  } catch {}
  return meta;
}

const agentName = process.env.NATS_AGENT_NAME ?? autoDetectName();
const description = process.env.NATS_AGENT_DESCRIPTION ?? `Claude Code agent on ${agentName}`;
const url = process.env.NATS_URL;
const credentials = process.env.NATS_CREDENTIALS;
const metadata = autoDetectMetadata();

// --- Start ---
async function main() {
  // 1. Connect to NATS
  const nc = await connectToNats({ url, credentials, name: `claude-code-${agentName}` });
  log(`connected to NATS`);

  // 2. Create MCP server with live connection
  // Identity is set after registerAgent (which generates it), accessed via closure
  let agentIdentity: import("@synadia/nats-agent-shared").AgentIdentity | null = null;
  const server = createNatsChannelServer({ agentName, nc, getIdentity: () => agentIdentity });

  // 3. Register agent on NATS (micro service + inbox handler)
  const agent = await startNatsBridge({ agentName, description, nc, server, metadata });
  agentIdentity = agent.identity;
  log(`agent "${agentName}" registered (xkey: ${agentIdentity.publicXKey})`);

  // 4. Connect MCP server to stdio transport
  const transport = new StdioServerTransport();
  await server.connect(transport);
  log(`MCP channel server running`);

  // 5. Shutdown handling
  const shutdown = async () => {
    log(`shutting down...`);
    await agent.stop();
    await drainConnection(nc);
    process.exit(0);
  };
  process.on("SIGTERM", shutdown);
  process.on("SIGINT", shutdown);
}

main().catch((err) => {
  log("fatal:", err);
  process.exit(1);
});
