/**
 * Minimal type stubs for openclaw/plugin-sdk/core.
 * Real types come from the OpenClaw runtime when the plugin is loaded.
 */

export type OpenClawConfig = Record<string, unknown>;

export type PluginRuntime = Record<string, unknown>;

export interface ChannelPlugin<ResolvedAccount = unknown, Probe = unknown, Audit = unknown> {
  id: string;
  meta: Record<string, unknown>;
  capabilities: Record<string, unknown>;
  [key: string]: unknown;
}

export interface ChannelAccountSnapshot {
  accountId?: string;
  label?: string;
  summary?: string;
  state?: string;
  [key: string]: unknown;
}

export declare function createChatChannelPlugin<
  TResolvedAccount extends { accountId?: string | null },
  Probe = unknown,
  Audit = unknown,
>(params: {
  base: Record<string, unknown>;
  security?: Record<string, unknown>;
  pairing?: Record<string, unknown>;
  threading?: Record<string, unknown>;
  outbound?: Record<string, unknown>;
}): ChannelPlugin<TResolvedAccount, Probe, Audit>;

export declare function defineChannelPluginEntry<TPlugin>(options: {
  id: string;
  name: string;
  description: string;
  plugin: TPlugin;
  setRuntime?: (runtime: PluginRuntime) => void;
  registerCliMetadata?: (api: unknown) => void;
  registerFull?: (api: unknown) => void;
}): unknown;

export declare function buildChannelOutboundSessionRoute(params: {
  cfg: OpenClawConfig;
  agentId: string;
  channel: string;
  accountId?: string | null;
  peer: { kind: string; id: string };
  chatType: string;
  from: string;
  to: string;
  threadId?: string | number;
}): unknown;

export declare const DEFAULT_ACCOUNT_ID: string;

export interface ChannelSetupWizard {
  channel: string;
  status: {
    configuredLabel?: string;
    unconfiguredLabel?: string;
    configuredScore?: number;
    unconfiguredScore?: number;
    resolveConfigured?: (params: { cfg: OpenClawConfig }) => boolean;
    [key: string]: unknown;
  };
  credentials: Array<Record<string, unknown>>;
  textInputs?: Array<{
    inputKey: string;
    message: string;
    placeholder?: string;
    required?: boolean;
    initialValue?: (params: Record<string, unknown>) => string | undefined;
    currentValue?: (params: Record<string, unknown>) => string | undefined;
    validate?: (value: string) => string | null;
    [key: string]: unknown;
  }>;
  completionNote?: { title?: string; message: string };
  disable?: (cfg: OpenClawConfig) => OpenClawConfig;
  [key: string]: unknown;
}
