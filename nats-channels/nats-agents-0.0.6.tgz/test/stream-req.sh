#!/usr/bin/env bash
set -euo pipefail

# Stream a request to an agent and print chunks as they arrive.
# Usage: stream-req.sh [--org <org>] <agent-name> <message>
#
# Unlike `nats req` (which waits for one response), this subscribes to a
# reply inbox and prints each chunk as it arrives. Exits on the done signal.

ORG=""
if [[ "${1:-}" == "--org" ]]; then
  ORG="${2:?--org requires a value}"
  shift 2
fi

AGENT=${1:?usage: stream-req.sh [--org <org>] <agent> <message>}
shift
MESSAGE="$*"
if [[ -z "$MESSAGE" ]]; then
  echo "usage: stream-req.sh [--org <org>] <agent> <message>"
  exit 1
fi

INBOX="_INBOX.stream.$(openssl rand -hex 8)"
if [[ -n "$ORG" ]]; then
  SUBJECT="${ORG}.agents.${AGENT}.inbox"
else
  SUBJECT="agents.${AGENT}.inbox"
fi

echo "→ ${SUBJECT}"
echo "← subscribing to ${INBOX}"
echo ""

# Subscribe to reply inbox in background, watch for done signal
nats sub "$INBOX" 2>/dev/null | while IFS= read -r line; do
  # Check for done header
  if [[ "$line" == *"Nats-Agent-Stream-Status: done"* ]]; then
    echo ""
    kill $$ 2>/dev/null || true
    break
  fi
  # Print payload lines (skip nats sub metadata lines starting with [)
  if [[ "$line" != "["* && "$line" != *"Nats-Agent"* ]]; then
    printf "%s" "$line"
  fi
done &
SUB_PID=$!

# Give subscription time to register
sleep 0.3

# Publish request with reply-to and stream header
nats pub "$SUBJECT" \
  "{\"from\":\"cli\",\"body\":\"$MESSAGE\"}" \
  --reply "$INBOX" \
  --header "Nats-Agent-Stream:accepted" 2>/dev/null

# Wait for sub to finish (exits on done signal)
wait $SUB_PID 2>/dev/null || true
echo ""
