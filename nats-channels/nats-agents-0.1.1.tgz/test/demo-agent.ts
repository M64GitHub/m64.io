import { connectToNats, drainConnection } from "../shared/connection.js";
import { registerAgent } from "../shared/micro.js";

async function main() {
  const nc = await connectToNats();

  const agent = await registerAgent(
    nc,
    {
      name: "demo-agent",
      description: "A demo agent that echoes messages",
      platform: "demo",
    },
    async (envelope) => {
      console.log(`[demo] received from "${envelope.from}": ${envelope.body}`);
      return `echo: ${envelope.body}`;
    },
  );

  console.log(`\nAgent running (xkey: ${agent.identity.publicXKey}). Try:`);
  console.log("  nats micro list");
  console.log("  nats micro info demo-agent");
  console.log('  nats req agents.demo-agent.inbox \'{"from":"cli","body":"hello"}\' --timeout 30s');
  console.log('  nats req agents.demo-agent.inspect \'\'');
  console.log("\nCtrl+C to stop.\n");

  process.on("SIGINT", async () => {
    await agent.stop();
    await drainConnection(nc);
    process.exit(0);
  });
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
