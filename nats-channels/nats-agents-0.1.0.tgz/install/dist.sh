#!/usr/bin/env bash
set -euo pipefail

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname "$SCRIPT_DIR")"
VERSION=$(node -p "require('$REPO_DIR/package.json').version")
OUTFILE="$SCRIPT_DIR/nats-agents-${VERSION}.tgz"

cd "$REPO_DIR"

tar czf "$OUTFILE" \
    package.json tsconfig.json README.md index.ts openclaw.plugin.json \
    doc/ shared/ src/ typings/ install/ test/

echo "Created $OUTFILE"
