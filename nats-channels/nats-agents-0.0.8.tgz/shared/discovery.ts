import type { NatsConnection } from "@nats-io/nats-core";
import { Svcm } from "@nats-io/services";
import { randomUUID } from "crypto";
import type { AgentInfo, InspectResponse } from "./types.js";
import type { AgentIdentity } from "./identity.js";
import {
  decryptMessage,
  encryptMessageRetainingSession, decryptChunk,
  HEADER_SENDER_XKEY,
  type SessionKeyMaterial,
} from "./crypto.js";
import {
  AGENT_TYPE,
  HEADER_STREAM_STATUS,
  HEADER_CRYPTO_MODE,
  STREAM_STATUS_DONE,
  CRYPTO_MODE_STREAM,
  buildEnvelope,
  agentSubject,
  inspectSubject,
  toNatsHeaders,
  fromNatsHeaders,
} from "./protocol.js";

const DEFAULT_DISCOVERY_TIMEOUT = 3000;
const DEFAULT_AGENT_TIMEOUT = 120_000;

export async function discoverAgents(
  nc: NatsConnection,
  timeout: number = DEFAULT_DISCOVERY_TIMEOUT,
): Promise<AgentInfo[]> {
  const svc = new Svcm(nc);
  const client = svc.client({ strategy: "stall", maxWait: timeout });
  const pings = await client.ping();

  const agents: AgentInfo[] = [];
  for await (const identity of pings) {
    if (identity.metadata?.type !== AGENT_TYPE) continue;
    agents.push({
      name: identity.name,
      id: identity.id,
      version: identity.version,
      description: identity.metadata.description ?? "",
      platform: identity.metadata.platform ?? "unknown",
      metadata: identity.metadata,
    });
  }

  return agents;
}

export async function getAgentInfo(
  nc: NatsConnection,
  name: string,
  opts?: {
    timeout?: number;
    identity?: AgentIdentity;
    org?: string;
  },
): Promise<InspectResponse> {
  const timeout = opts?.timeout ?? DEFAULT_DISCOVERY_TIMEOUT;
  const nonce = randomUUID();
  const msg = await nc.request(inspectSubject(name, opts?.org), nonce, { timeout });
  const info = JSON.parse(msg.string()) as InspectResponse;

  // Verify the agent signed our nonce (proves key ownership)
  if (opts?.identity) {
    info.verified = opts.identity.verify(nonce, info.identity.signature, info.identity.publicNKey);
  }

  return info;
}

const DEFAULT_STALL_MS = 5000;

/**
 * Send a message to another agent and get the response.
 * Uses requestMany() with stall strategy to handle both streaming and
 * non-streaming agents. Streaming agents publish chunks + empty done signal.
 * Non-streaming agents send one response (stall timeout expires).
 * When encryption is enabled, encrypts with session key for streaming support.
 */
export async function sendToAgent(
  nc: NatsConnection,
  senderName: string,
  targetName: string,
  message: string,
  opts?: {
    timeout?: number;
    identity?: AgentIdentity;
    encryption?: boolean;
    org?: string;
    stallMs?: number;
    onChunk?: (text: string, info: { seq: number; done: boolean }) => void;
  },
): Promise<string> {
  const timeout = opts?.timeout ?? DEFAULT_AGENT_TIMEOUT;
  const identity = opts?.identity;
  const encryption = opts?.encryption === true;
  const org = opts?.org;
  const stallMs = opts?.stallMs ?? DEFAULT_STALL_MS;
  const envelopeStr = buildEnvelope(senderName, message);

  let reqHeaders: Record<string, string> = {};
  let session: SessionKeyMaterial | undefined;
  let payload: Uint8Array | string;

  if (identity && encryption) {
    const info = await getAgentInfo(nc, targetName, { identity, org });
    const encrypted = encryptMessageRetainingSession(
      new TextEncoder().encode(envelopeStr),
      identity.xkey,
      info.identity.publicXKey,
    );
    payload = encrypted.payload;
    reqHeaders = encrypted.headers;
    session = encrypted.session;
  } else {
    payload = envelopeStr;
  }

  const iter = await nc.requestMany(agentSubject(targetName, org), payload, {
    strategy: "stall",
    stall: stallMs,
    maxWait: timeout,
    headers: Object.keys(reqHeaders).length > 0 ? toNatsHeaders(reqHeaders) : undefined,
  });

  let accumulated = "";
  for await (const msg of iter) {
    const hdrs = fromNatsHeaders(msg.headers);
    const status = hdrs[HEADER_STREAM_STATUS];
    const seq = parseInt(hdrs["Nats-Agent-Stream-Seq"] ?? "0", 10);

    // Empty done signal — return accumulated chunks
    if (status === STREAM_STATUS_DONE && msg.data.length === 0) {
      opts?.onChunk?.("", { seq, done: true });
      return accumulated;
    }

    let text: string;
    if (session && hdrs[HEADER_CRYPTO_MODE] === CRYPTO_MODE_STREAM) {
      // Streaming chunk encrypted with session key
      text = new TextDecoder().decode(decryptChunk(session, seq, msg.data));
    } else if (identity && hdrs[HEADER_SENDER_XKEY]) {
      // Per-message encryption (non-streaming agent response)
      text = new TextDecoder().decode(decryptMessage(msg.data, hdrs, identity.xkey));
    } else {
      text = new TextDecoder().decode(msg.data);
    }

    accumulated += text;
    opts?.onChunk?.(text, { seq, done: false });
  }

  return accumulated;
}
