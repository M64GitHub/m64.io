#!/usr/bin/env bash
set -euo pipefail

VERSION=${1:?usage: dist.sh <version>  (e.g. dist.sh 0.1.0)}

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_DIR="$(dirname "$SCRIPT_DIR")"
OUTFILE="$SCRIPT_DIR/nats-agents-${VERSION}.tgz"

cd "$REPO_DIR"

tar czf "$OUTFILE" \
    package.json tsconfig.json README.md index.ts openclaw.plugin.json \
    doc/ shared/ src/ typings/ install/ test/

# Update version in openclaw.sh installer
sed -i "s|PLUGIN_VERSION=\"[0-9.]*\"|PLUGIN_VERSION=\"${VERSION}\"|" "$SCRIPT_DIR/openclaw.sh"

echo "Created $OUTFILE"
echo "Updated openclaw.sh → nats-agents-${VERSION}.tgz"
