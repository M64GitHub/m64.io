import type { NatsConnection, Subscription } from "@nats-io/nats-core";
import { Svcm } from "@nats-io/services";
import type { ServiceHandler } from "@nats-io/services";
import type { AgentConfig, MessageHandler, RegisteredAgent } from "./types.js";
import { generateIdentity } from "./identity.js";
import type { AgentIdentity } from "./identity.js";
import { encryptMessage, decryptMessage, HEADER_SENDER_XKEY } from "./crypto.js";
import {
  AGENT_TYPE,
  DEFAULT_VERSION,
  buildInspectResponse,
  inboxSubject,
  inspectSubject,
  parseEnvelope,
  toNatsHeaders,
  fromNatsHeaders,
} from "./protocol.js";

export async function registerAgent(
  nc: NatsConnection,
  config: AgentConfig,
  handler: MessageHandler,
): Promise<RegisteredAgent> {
  const identity = generateIdentity();
  const version = config.version ?? DEFAULT_VERSION;

  const svc = new Svcm(nc);
  const service = await svc.add({
    name: config.name,
    version,
    description: config.description,
    metadata: {
      type: AGENT_TYPE,
      platform: config.platform,
      description: config.description,
      public_nkey: identity.publicNKey,
      public_xkey: identity.publicXKey,
      ...config.metadata,
    },
  });

  // Inbox endpoint — handles incoming prompts via request/reply
  // Messages may be encrypted (has crypto headers) or plaintext (backward compat)
  const inboxHandler: ServiceHandler = (err, msg) => {
    if (err) return;
    try {
      const hdrs = fromNatsHeaders(msg.headers);
      const isEncrypted = Boolean(hdrs[HEADER_SENDER_XKEY]);

      let envelopeData: Uint8Array | string;
      let senderXKey: string | undefined;

      if (isEncrypted) {
        envelopeData = decryptMessage(msg.data, hdrs, identity.xkey);
        senderXKey = hdrs[HEADER_SENDER_XKEY];
      } else {
        envelopeData = msg.data;
      }

      const envelope = parseEnvelope(envelopeData);

      handler(envelope).then(
        (response) => {
          if (isEncrypted && senderXKey) {
            const encrypted = encryptMessage(
              new TextEncoder().encode(response),
              identity.xkey,
              senderXKey,
            );
            msg.respond(encrypted.payload, { headers: toNatsHeaders(encrypted.headers) });
          } else {
            msg.respond(response);
          }
        },
        (error) => msg.respondError(500, (error as Error).message),
      );
    } catch (e) {
      msg.respondError(400, (e as Error).message);
    }
  };

  service.addEndpoint("inbox", {
    subject: inboxSubject(config.name),
    handler: inboxHandler,
  });

  // INSPECT endpoint — returns agent capabilities (unencrypted, public by design)
  // If the request contains a nonce, sign it to prove key ownership
  const inspectSub: Subscription = nc.subscribe(inspectSubject(config.name), {
    callback: (_err, msg) => {
      const nonce = msg.data.length > 0 ? new TextDecoder().decode(msg.data) : undefined;
      const response = buildInspectResponse(config, identity, nonce);
      msg.respond(JSON.stringify(response));
    },
  });

  console.log(
    `[agent] registered "${config.name}" (${config.platform}) — inbox: ${inboxSubject(config.name)}`,
  );

  return {
    service,
    identity,
    stop: async () => {
      inspectSub.unsubscribe();
      await service.stop();
      console.log(`[agent] stopped "${config.name}"`);
    },
  };
}
